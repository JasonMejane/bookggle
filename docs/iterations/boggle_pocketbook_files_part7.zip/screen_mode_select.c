/* Mode select screen. */

#include "screen_mode_select.h"
#include "game_state.h"
#include "i18n.h"

void draw_mode_select(void) {
    FillArea(0, 0, SW, SH, WHITE);

    SetFont(font_title, BLACK);
    DrawTextRect(0, SH / 8, SW, 52, "BOGGLE", ALIGN_CENTER);

    SetFont(font_medium, BLACK);
    DrawTextRect(0, SH / 8 + 62, SW, 30,
                 i18n_str(STR_CHOOSE_MODE), ALIGN_CENTER);

    int bw = SW * 2 / 3, bh = 64, bx = (SW - bw) / 2;
    int solo_y  = SH * 2 / 5;
    int multi_y = solo_y + bh + 54;
    int btn_text_w = bw - 20;

    DrawRect(bx, solo_y, bw, bh, BLACK);
    const char *solo_label = i18n_str(STR_BTN_SOLO);
    SetFont(i18n_fit_font(solo_label, btn_text_w, font_large), BLACK);
    DrawTextRect(bx, solo_y + 10, bw, bh, solo_label, ALIGN_CENTER);
    SetFont(font_small, DGRAY);
    DrawTextRect(bx, solo_y + bh + 4, bw, 22,
                 i18n_str(STR_SOLO_HINT), ALIGN_CENTER);

    DrawRect(bx, multi_y, bw, bh, BLACK);
    const char *multi_label = i18n_str(STR_BTN_MULTIPLAYER);
    SetFont(i18n_fit_font(multi_label, btn_text_w, font_large), BLACK);
    DrawTextRect(bx, multi_y + 10, bw, bh, multi_label, ALIGN_CENTER);
    SetFont(font_small, DGRAY);
    DrawTextRect(bx, multi_y + bh + 4, bw, 22,
                 i18n_str(STR_MULTI_HINT), ALIGN_CENTER);

    /* Board-size toggle: 4x4 / 5x5. Filled = currently selected.
       Digits + "x" aren't prose, so left as a plain literal like
       "BOGGLE" above rather than routed through i18n. */
    int board_btn_w = 90, board_btn_h = 40, board_gap = 20;
    int board_total_w = board_btn_w * 2 + board_gap;
    int board_x = (SW - board_total_w) / 2;
    int board_y = multi_y + bh + 4 + 22 + 24;

    board4_btn_x = board_x;                          board4_btn_y = board_y;
    board4_btn_w = board_btn_w;                       board4_btn_h = board_btn_h;
    board5_btn_x = board_x + board_btn_w + board_gap; board5_btn_y = board_y;
    board5_btn_w = board_btn_w;                       board5_btn_h = board_btn_h;

    int fill4 = (selected_board_size == 4) ? BLACK : WHITE;
    int text4 = (selected_board_size == 4) ? WHITE : BLACK;
    FillArea(board4_btn_x, board4_btn_y, board4_btn_w, board4_btn_h, fill4);
    DrawRect(board4_btn_x, board4_btn_y, board4_btn_w, board4_btn_h, BLACK);
    SetFont(font_medium, text4);
    DrawTextRect(board4_btn_x, board4_btn_y + 8, board4_btn_w, board4_btn_h,
                 "4x4", ALIGN_CENTER);

    int fill5 = (selected_board_size == 5) ? BLACK : WHITE;
    int text5 = (selected_board_size == 5) ? WHITE : BLACK;
    FillArea(board5_btn_x, board5_btn_y, board5_btn_w, board5_btn_h, fill5);
    DrawRect(board5_btn_x, board5_btn_y, board5_btn_w, board5_btn_h, BLACK);
    SetFont(font_medium, text5);
    DrawTextRect(board5_btn_x, board5_btn_y + 8, board5_btn_w, board5_btn_h,
                 "5x5", ALIGN_CENTER);

    FullUpdate();
}
