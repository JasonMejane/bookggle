# Boggle for PocketBook — Developer Guide

Native C Boggle game for PocketBook e-readers, built on the InkView SDK.

## Setup screen

Before a game starts, a setup screen shows three independent toggles
— **Mode** (Solo / Multiplayer), **Grid size** (4×4 / 5×5), **Timer**
(1:30 / 3:00) — plus a **Start** button. Toggles only change a
selection (`selected_mode`, `selected_board_size`,
`selected_timer_seconds`, all in `src/include/game_state.h`); nothing
begins until Start is tapped. This is deliberate: tapping "Solo" no
longer jumps straight into a game the way earlier versions of this
screen did, so a mis-tap while adjusting one setting can't
accidentally start a mismatched game with the others still at their
old values.

- **Solo** — tap cells to spell words, live score, word list.
- **Multiplayer** — only the grid and timer are shown. Each player
  notes words on paper. At 0:00 the **grid disappears** and an end
  screen tells players to compare lists (words found by more than one
  player cancel out — standard Boggle rule).
- **Grid size** — 4×4 (standard) or 5×5 ("Big Boggle"), independent of
  Solo/Multiplayer.
- **Timer** — 1:30 or 3:00, independent of the other two. Read by
  `game_start()` (`src/game_logic.c`) via `selected_timer_seconds`
  instead of the old hardcoded 3-minute constant.

The setup screen is shown at startup, or anytime via the **"Mode"**
button (top-right of the in-game HUD), which returns to it without
losing the current selections. The physical **Back** key does the
same (or closes the app if already on that screen).

## Game screen

Top to bottom: HUD (title, timer, score in Solo), the grid, then a
**Pause/Play** button, then the word bar (Solo) or a hint (Multiplayer).

- **Pause** freezes the timer and hides every cell's letter (the grid
  outline stays visible, just blank) without losing any progress.
  **Play** resumes the timer from exactly where it was and shows the
  letters again. The button's own label flips between the two —
  "Pause" while running, "Play" while paused — so it always describes
  what tapping it will do next, not the current state.
- While paused, touching a cell does nothing (same guard as
  Multiplayer mode or after time runs out) — the underlying grid data
  is never touched by pausing, only what's drawn and what input does
  with it.
- Submit/Clear stay active while paused, since finishing a word you
  already built before pausing doesn't reveal anything new.

Two buttons sit in the HUD's top-right corner: **"Mode"** (returns to
the setup screen; tapping "Start" again from there begins a brand new
game, not a resume — the in-progress game's state isn't preserved
once you leave this screen) and **"Quit"** (closes the app
immediately, no confirmation prompt, same directness as every other
button in this app).

## Language follows the device; board size is a separate player choice

Every menu, button, and dialog is looked up by key (`src/i18n.c` /
`src/include/i18n.h`) and resolved against the device's current
system language automatically via the InkView SDK's
`GetCurrentLangText()` — no manual locale detection in the app. Two
languages ship today: English (`src/i18n_strings_en.c`) and French
(`src/i18n_strings_fr.c`). Adding another is one new table file plus
one line in `i18n_init()` — no changes to any `screen_*.c` file.

Buttons with fixed pixel widths (Solo/Multiplayer/Submit/Clear/Mode/
Quit/Pause/Play/Start/New game/Change mode) use `i18n_fit_font()` to
shrink through the font ladder (`font_large` → `font_medium` →
`font_small`) via `StringWidth()` measurement, so a longer translation
doesn't overflow its box. Grid cell letters use the same measurement,
since a 5×5 board's smaller cells can make even a single letter (or
the "Qu" digraph) tight.

The **grid roll and word rules also follow a ruleset** (`GameRuleset`,
`src/include/ruleset.h`) — not just the menu text. But unlike the UI
language, **board size is a deliberate player choice, not something
that follows the device automatically** — a French-speaking player
picking the bigger grid still expects a French UI, and a device being
in French doesn't imply a player wants (or doesn't want) 5×5. So
`ruleset_select(board_size)` takes two independent inputs: the device
language (same signal as the UI strings, via `i18n_str(STR_LANG_CODE)`)
and the board size the player picked. `ruleset_active()` returns the
result everywhere the game needs dice letters, the Q/Qu digraph rule,
or the minimum word length.

Four rulesets ship today:

```
English 4x4 ("New Boggle" 16-dice set):
AAEEGN ABBJOO ACHOPS AFFKPS AOOTTW CIMOTU DEILRX DELRVY
DISTTY EEGHNW EEINSU EHRTVW EIOSST ELRTTY HIMNQU HLNNRZ

English 5x5 ("Big Boggle" 25-dice set):
AAAFRS AAEEEE AAFIRS ADENNN AEEEEM AEEGMU AEGMNN AFIRSY
BJKQXZ CCENST CEIILT CEILPT CEIPST DDHNOT DHHLOR DHLNOR
DHLNOR EIIITT EMOTTT ENSSSU FIPRSY GORRVW IPRRRY NOOTUW
OOOTTU

French 4x4 (B@ggle, baggle.org/regles.php):
ETUKNO EVGTIN DECAMP IELRUW EHIFSE RECALS ENTDOS OFXRIA
NAVEDZ EIOATA GLENYU BMAQJO TLIBRA SPULTE AIMSOR ENHRIS

French 5x5 (Big B@ggle, 25-dice set):
MDNSNH GFSTEY LMTRXS TTRSCH BMLNDL TMRDBT EIUEAO RLXSSB
NAATEQ TCJFSH IEEAOA NDHSNM IAAIEO OEUEIA LCPRJS DSTLSM
NKLPFN DWRNLP RZNNTQ RGLRVF RVCGRT IIOEAE EUIAEO UIAEOA
NSEVAE
```

Each line above is a 6-face die. `dice_roll_grid()` in **`src/dice.c`**
shuffles the active ruleset's dice (Fisher-Yates) into the grid, then
rolls one face per die — unlike picking from a flat letter-frequency
bag, this guarantees a bounded, ruleset-specific number of Q and Z
dice per grid rather than an unbounded one. Three of the four bundled
tables have exactly one die each carrying Q and one carrying Z (the
English 5×5 set even puts both on the same physical die, confirmed by
its sourcing trail, not a transcription bug); the **French 5×5 table
genuinely has two dice carrying Q** (`tests/test_dice.c` checks each
ruleset against its own expected count rather than assuming "at most
one" universally). All four rulesets merge Q as **"Qu"**: the cell
displays `Qu`, selecting it inserts the `QU` digraph into the word
being built, and scoring counts **cells** walked (not characters).
This is a per-ruleset flag (`has_qu_digraph`), not hardcoded.

The 4×4 and 5×5 rulesets deliberately differ in minimum word length
— **3 letters at 4×4, 4 letters at 5×5** — confirmed by multiple
official Big Boggle rule sheets and by baggle.org's own Big B@ggle
rules text for French. This is a per-ruleset field (`min_word_len`),
read at validation time (`ruleset_active()->min_word_len` in
`game_logic.c`), so the "too short" dialog is templated with `%d`
rather than hardcoding either number.

Board size itself is **not** a compile-time constant — `GameState`'s
grid/selection arrays are sized for the larger board (5×5) and a
runtime `g.board_size` field tracks how much of them is in play (see
`MAX_BOARD_SIZE`/`MAX_DICE_COUNT` in `src/include/game_state.h`).
Screen layout (`CELL_SIZE`/`GRID_X`/`GRID_Y`) is computed per game,
after the board size is known (`layout_compute_grid()`, called from
`game_start()`), with a board-size-aware width budget (60% of screen
width at 4×4, 75% at 5×5) so touch targets stay a comparable physical
size on both boards rather than shrinking with the extra column.

Adding a language's *rules* (not just its menu text) means a new
`ruleset_<code>_<size>.c` data file plus a line in `ruleset_select()`
— see `docs/i18n_plan_tier2.md` for the original 4×4-only design
rationale and `docs/board_size_5x5_plan.md` for the board-size
extension, including the full citation trail for both English dice
tables and the Big Boggle rule confirmations.

---

## InkView SDK essentials

PocketBook apps are ARM ELF binaries linked against `libinkview.so`.
The SDK provides the cross-compiler and headers.

```c
int main(int argc, char **argv) {
    InkViewMain(main_handler);
    return 0;
}
```

`InkViewMain` runs the event loop; your code lives in
`main_handler(int type, int par1, int par2)`.

| Event             | Trigger              | par1 / par2         |
|--------------------|-----------------------|----------------------|
| `EVT_INIT`         | App startup           | —                    |
| `EVT_SHOW`         | Screen needs redraw    | —                    |
| `EVT_EXIT`         | App closing            | —                    |
| `EVT_KEYPRESS`     | Physical key pressed   | par1 = key code      |
| `EVT_POINTERUP`    | Finger lifted (touch)  | par1 = X, par2 = Y   |
| `EVT_POINTERDOWN`  | Finger pressed         | par1 = X, par2 = Y   |

```c
FillArea(x, y, w, h, WHITE);

ifont *f = OpenFont("LiberationSans", 24, 1);
SetFont(f, BLACK);
DrawString(x, y, "Hello!");
DrawTextRect(x, y, w, h, "centered text", ALIGN_CENTER);

DrawRect(x, y, w, h, BLACK);

FullUpdate();           // full refresh, slow, clean
PartialUpdate(x,y,w,h);  // fast, may ghost
```

> On e-ink, whatever is drawn stays until you cover it. Always
> `FillArea(..., WHITE)` before redrawing.

```c
SetHardTimer("MyTimer", my_callback, 1000);

static void my_callback(int id) {
    // ... update + PartialUpdate(...)
}
```

> Here, the countdown lives in **`src/timer.c`** and draws nothing —
> it returns a `TimerTickResult`. The adapter `on_timer_tick()` in
> **`src/main.c`** is the one actually registered with `SetHardTimer`
> (which requires `void(*)(int)`), and it picks the redraw.

---

## Project layout

One `.c` / `.h` pair per concern, headers in `src/include/`.

```
boggle-pocketbook/
├── src/
│   ├── include/
│   │   ├── game_state.h          shared types, constants, extern state
│   │   ├── ui_fonts.h            font loading + screen layout
│   │   ├── dice.h                shuffle-and-roll mechanics only
│   │   ├── game_logic.h          rules: grid, selection, score, Q/Qu
│   │   ├── timer.h               game timer
│   │   ├── i18n.h                string keys, translation lookup, fit-font
│   │   ├── ruleset.h             per-(language, board size) dice/digraph/word-length rules
│   │   ├── screen_mode_select.h
│   │   ├── screen_game.h
│   │   ├── screen_multi_end.h
│   │   └── input.h               touch/key routing
│   ├── game_state.c       single definition of global state `g`
│   ├── ui_fonts.c
│   ├── dice.c              shuffle-and-roll mechanics only, no letters
│   ├── game_logic.c       pure logic, no drawing
│   ├── timer.c            pure logic, no drawing
│   ├── i18n.c             registration + lookup + fit-font
│   ├── i18n_strings_en.c  English string table
│   ├── i18n_strings_fr.c  French string table
│   ├── ruleset.c          selects active ruleset (language x board size)
│   ├── ruleset_en_4x4.c   English 4x4 dice table + rules
│   ├── ruleset_en_5x5.c   English 5x5 ("Big Boggle") dice table + rules
│   ├── ruleset_fr_4x4.c   French 4x4 dice table + rules
│   ├── ruleset_fr_5x5.c   French 5x5 ("Big B@ggle") dice table + rules
│   ├── screen_mode_select.c
│   ├── screen_game.c
│   ├── screen_multi_end.c
│   ├── input.c
│   └── main.c              main_handler + main()
├── tests/             host tests, no SDK/device — see tests/README.md
├── docs/
│   ├── i18n_plan_tier1.md       UI string localization (implemented)
│   ├── i18n_plan_tier2.md       game-rules localization (implemented)
│   └── board_size_5x5_plan.md   4x4/5x5 board size (implemented)
├── CMakeLists.txt
├── Makefile
└── README.md
```

`game_state.h` is the shared-data contract, included almost
everywhere. `game_logic.c` and `timer.c` never call `Draw*`/`Fill*`
and never include a `screen_*.h` — pure logic, testable without
drawing (see `tests/`). `game_logic.c` calls `i18n_str()` (for its
warning dialogs), `ruleset_active()` (for the Q/Qu digraph and
minimum word length), and `layout_compute_grid()` (from `game_start()`,
once the board size is known), so it depends on `i18n.h`, `ruleset.h`,
and `ui_fonts.h`, but those are lookups and layout math, not drawing
calls. `dice.c` depends on `ruleset.h` too — it owns the shuffle/roll
mechanics only, not any specific set of letters or a specific board
size.

`timer.c` can't register directly with `SetHardTimer` (its
`game_timer_callback` returns `TimerTickResult`, not `void`), so it
registers `on_timer_tick(int)` instead — declared in `timer.h`,
defined in `main.c`, which calls `game_timer_callback()` and chooses
the redraw. This keeps timer rules and screen rendering independently
changeable.

`ruleset.c` picks the active ruleset from **two** independent inputs:
device language (reusing `i18n`'s own resolution — each language
table carries one extra, non-user-facing entry, `STR_LANG_CODE`, whose
translated value is simply its own language code, so `ruleset_select()`
reads it through `i18n_str()` rather than a second detection
mechanism) and the board size the player picked
(`selected_board_size`, set by the mode-select screen's toggle). It's
deliberately not a single combined lookup — see the README's
"Language follows the device" section above for why board size and
language are kept independent.

---

## PocketBook SDK

Get the SDK: https://github.com/pocketbook/SDK_6.3.0

Or use the Docker image:
```bash
docker pull 5keeve/pocketbook-sdk:6.3.0-b288-v1
```

## Build

```bash
export PBSDK=$HOME/SDK_6.3.0
make
```

CMake:
```bash
export PBSDK=$HOME/SDK_6.3.0
mkdir build && cd build
cmake .. -DCMAKE_TOOLCHAIN_FILE=$PBSDK/share/cmake/arm_conf.cmake
make
```

Docker, no local SDK install:
```bash
docker run --rm -v $(pwd):/project -w /project \
  5keeve/pocketbook-sdk:6.3.0-b288-v1 \
  sh -c 'arm-obreey-linux-gnueabi-gcc -Isrc/include src/*.c \
         -o boggle.app -linkview -lm'
```

Check the binary is ARM:
```bash
file boggle.app
# -> ELF 32-bit LSB executable, ARM, EABI5 ...
```

## Run logic without a device

`tests/` provides a no-op InkView stub so the game logic builds and
runs on a regular dev machine:

```bash
cd tests
make
```

Six suites: `test_flow.c` (full 4x4 game scenario, 20 checks),
`test_dice.c` (dice roll, bijection + Q/Z uniqueness, once per bundled
ruleset — en-4x4/en-5x5/fr-4x4/fr-5x5), `test_game_start_dice.c` (game_start
<-> dice integration, both board sizes), `test_i18n.c` (translation
completeness across languages + fit-font sizing), `test_ruleset.c`
(ruleset selection across all 4 bundled language x board-size pairs,
plus the unknown-language fallback), `test_flow_5x5.c` (full 5x5 cycle
and the min_word_len=4 rule). See `tests/README.md` for details.

## Deploy to device

1. Connect over USB (mass storage mode)
2. Copy `boggle.app` to `/mnt/ext1/applications/boggle.app`
3. Disconnect, launch from the Applications menu

Or via SSH (dropbear):
```bash
scp boggle.app root@192.168.1.X:/mnt/ext1/applications/boggle.app
```

---

## Extending

**Dictionary** — `word_is_valid()` in `src/game_logic.c` only checks
length right now (against `ruleset_active()->min_word_len`). A real
dictionary needs one word list per language, not one global list —
natural fit alongside the existing per-language split: load
`dict_en.txt`/`dict_fr.txt` based on `ruleset_active()->lang_code`,
or add a `dict_path` field to `GameRuleset` itself. Sorted word list +
binary search:

```c
static char dict[50000][16];
static int  dict_size = 0;

void load_dict(void) {
    FILE *f = fopen("/mnt/ext1/applications/boggle.dict", "r");
    if (!f) return;
    while (fgets(dict[dict_size], 16, f) && dict_size < 50000) {
        dict[dict_size][strcspn(dict[dict_size], "\n")] = '\0';
        for (char *p = dict[dict_size]; *p; p++) *p = toupper(*p);
        dict_size++;
    }
    fclose(f);
}

int word_in_dict(const char *w) {
    int lo = 0, hi = dict_size - 1;
    while (lo <= hi) {
        int mid = (lo + hi) / 2;
        int cmp = strcmp(dict[mid], w);
        if (cmp == 0) return 1;
        if (cmp < 0) lo = mid + 1; else hi = mid - 1;
    }
    return 0;
}
```

**Screen refresh modes** — `FullUpdate()` is slow but clean,
`PartialUpdate(x,y,w,h)` is fast but may ghost. Use partial for
frequently-changing areas (grid, HUD), full for screen transitions.

---

## Links

- SDK & examples: https://github.com/pmartin/pocketbook-demo
- SDK Docker: https://github.com/Skeeve/SDK_6.3.0
- MobileRead forum: https://www.mobileread.com/forums/forumdisplay.php?f=225
- inkview.h headers: https://github.com/blchinezu/pocketbook-sdk
- French 4x4 dice letter layout source: http://baggle.org/regles.php
- English 4x4 dice, researched from
  https://boardgames.stackexchange.com/q/48151 and cross-checked
  against several independent published transcriptions
- English 5x5 ("Big Boggle") dice, physically verified against an
  owned 1979 set: https://en.wikipedia.org/wiki/Talk:Boggle
- Big Boggle's 4-letter minimum word length, confirmed by
  UltraBoardGames' rules page and by baggle.org's own Big B@ggle rules
  text — see `docs/board_size_5x5_plan.md` for the full citation trail
- French 5x5 ("Big B@ggle") dice: provided directly, not independently
  sourced/cited like the other three bundled rulesets
