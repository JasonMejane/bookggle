/**
 * dice.h — Table des 16 dés du Boggle 4×4 et tirage de la grille.
 *
 * Répartition officielle des lettres sur les 16 dés, telle que
 * documentée sur http://baggle.org/regles.php (section "Tirages
 * possibles") :
 *
 *   ETUKNO EVGTIN DECAMP IELRUW EHIFSE RECALS ENTDOS OFXRIA
 *   NAVEDZ EIOATA GLENYU BMAQJO TLIBRA SPULTE AIMSOR ENHRIS
 *
 * Contrairement à une simple distribution fréquentielle (piocher une
 * lettre au hasard dans un grand sac pondéré), un tirage Boggle fidèle
 * aux règles du jeu physique consiste à :
 *   1. mélanger l'ordre des 16 dés (chaque dé tombe dans une case
 *      différente, comme en secouant la boîte) ;
 *   2. pour chaque dé, tirer une face au hasard parmi ses 6 lettres.
 *
 * Cela garantit par exemple qu'il n'y a jamais plus d'un Q ou d'un Z
 * dans la grille (un seul dé porte cette lettre), ce qu'une simple
 * distribution fréquentielle ne garantit pas.
 */

#ifndef DICE_H
#define DICE_H

#define DICE_COUNT      16   /* un dé par case de la grille 4×4      */
#define DICE_FACES      6    /* 6 faces par dé                       */

/*
 * Remplit g.grid avec un tirage Boggle conforme aux règles physiques :
 * les 16 dés sont mélangés (ordre aléatoire dans les 16 cases), puis
 * une face est tirée au hasard pour chacun.
 *
 * Le digraphe Q (affiché "Qu", contribue "QU" au mot) est géré
 * séparément par game_logic.c — ce module se contente de placer la
 * lettre brute 'Q' dans la grille comme les 25 autres lettres.
 */
void dice_roll_grid(void);

#endif /* DICE_H */
