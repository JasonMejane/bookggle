# Boggle pour PocketBook — Guide développeur

Application Boggle native en C pour liseuses PocketBook, basée sur la
bibliothèque InkView (SDK PocketBook).

## Modes de jeu (v2)

- **Solo** : saisie tactile des mots case par case, validation, score
  affiché en temps réel, liste des mots trouvés.
- **Multijoueur** : la liseuse n'affiche que la grille et le chrono.
  Chaque joueur note ses mots de son côté (papier, etc.). Quand le
  temps atteint 0, **la grille disparaît automatiquement** et un écran
  de fin invite à comparer les listes (les mots trouvés par plusieurs
  joueurs s'annulent, règle Boggle classique).

Le choix du mode se fait :
- au lancement de l'app (écran d'accueil avec deux gros boutons),
- ou à tout moment en jeu via le bouton **"Mode"** en haut à droite du
  HUD, qui ramène à l'écran de sélection.

Le bouton physique **Back** ramène aussi à l'écran de sélection de
mode (et quitte l'app si on est déjà sur cet écran).

## Tirage de la grille : les 16 dés officiels du Boggle

Le tirage de la grille reproduit la répartition exacte des lettres
sur les 16 dés physiques du Boggle, telle que documentée par
[baggle.org/regles.php](http://baggle.org/regles.php) (section
« Tirages possibles ») :

```
ETUKNO EVGTIN DECAMP IELRUW EHIFSE RECALS ENTDOS OFXRIA
NAVEDZ EIOATA GLENYU BMAQJO TLIBRA SPULTE AIMSOR ENHRIS
```

Chaque ligne est un dé à 6 faces. Un tirage fidèle au jeu physique
consiste à **mélanger l'ordre des 16 dés** (chaque dé tombe dans une
case différente, comme en secouant la boîte), puis à **tirer une face
au hasard** pour chacun. C'est ce que fait `dice_roll_grid()` dans
**`src/dice.c`** : un mélange Fisher-Yates des 16 dés, puis un tirage
de face indépendant par dé.

Cette approche diffère d'une simple pioche dans une distribution de
fréquence globale (l'approche utilisée dans les versions précédentes
de ce projet) : elle garantit par exemple qu'**il n'y a jamais plus
d'un Q ou d'un Z dans la grille**, puisqu'un seul dé porte chacune de
ces lettres (`BMAQJO` pour Q, `NAVEDZ` pour Z) — une distribution de
fréquence pourrait en tirer deux par hasard, ce qui ne reflète pas le
jeu physique.

## Spécificité française : Q = "Qu"

Conformément aux règles du Boggle français, la face **Q** du dé est en
réalité **"Qu"** :
- la case affiche `Qu` (police réduite pour que ça tienne),
- la sélection de cette case insère le digraphe `QU` dans le mot en
  cours de construction,
- le score est calculé sur le nombre de **cases** parcourues (pas le
  nombre de caractères), donc `QU` ne compte que pour 1 case dans le
  barème de points.

---

## Architecture InkView SDK — l'essentiel

Les apps PocketBook sont des **binaires ARM ELF** liés à `libinkview.so`,
présente sur le firmware de la liseuse. Le SDK fournit le compilateur
croisé et les headers.

### Boucle principale

```c
int main(int argc, char **argv) {
    InkViewMain(main_handler);   // cède le contrôle à InkView
    return 0;
}
```

`InkViewMain` prend en charge la boucle d'événements. Votre code vit
entièrement dans `main_handler(int type, int par1, int par2)`.

### Événements clés

| Événement        | Déclencheur                        | par1 / par2            |
|------------------|------------------------------------|------------------------|
| `EVT_INIT`       | Démarrage de l'app                 | —                      |
| `EVT_SHOW`       | Écran doit être redessiné          | —                      |
| `EVT_EXIT`       | Fermeture de l'app                 | —                      |
| `EVT_KEYPRESS`   | Bouton physique pressé             | par1 = code touche     |
| `EVT_POINTERUP`  | Relâchement du doigt (tactile)     | par1 = X, par2 = Y     |
| `EVT_POINTERDOWN`| Appui du doigt                     | par1 = X, par2 = Y     |

### Machine à états de navigation (v2)

```
SCREEN_MODE_SELECT ──(tap Solo)───► SCREEN_GAME (mode = SOLO)
                    ──(tap Multi)──► SCREEN_GAME (mode = MULTI)

SCREEN_GAME ──(tap "Mode" / Back)───► SCREEN_MODE_SELECT
SCREEN_GAME[MULTI] ──(timer = 0)────► SCREEN_MULTI_END

SCREEN_MULTI_END ──(Nouvelle partie)──► SCREEN_GAME (mode = MULTI)
SCREEN_MULTI_END ──(Changer mode)─────► SCREEN_MODE_SELECT
```

La variable `cur_screen` pilote à la fois le rendu (`EVT_SHOW`) et le
routage des taps (`EVT_POINTERUP`) : chaque écran définit ses propres
zones de boutons, recalculées à partir de `SW`/`SH`, donc tout reste
cohérent quelle que soit la résolution de la liseuse.

### Dessin à l'écran (e-ink)

```c
// Effacer une zone
FillArea(x, y, w, h, WHITE);

// Police
ifont *f = OpenFont("LiberationSans", 24, 1);
SetFont(f, BLACK);
DrawString(x, y, "Bonjour !");
DrawTextRect(x, y, w, h, "texte centré", ALIGN_CENTER);

// Rectangle
DrawRect(x, y, w, h, BLACK);

// Rafraîchissement
FullUpdate();          // rafraîchissement complet (lent, bonne qualité)
PartialUpdate(x,y,w,h); // zone partielle (rapide, légèrement fantôme)
```

> ⚠️ Sur e-ink, ce qui est dessiné reste affiché jusqu'à ce que vous
> le recouvriez. Toujours `FillArea(..., WHITE)` avant de redessiner.

### Timer

```c
// Déclenche callback toutes les 1000 ms
SetHardTimer("MonTimer", ma_callback, 1000);

static void ma_callback(int id) {
    // ... mise à jour + PartialUpdate(...)
}
```

> Dans ce projet, cette logique est isolée dans **`src/timer.c`**
> (`game_timer_start` / `game_timer_callback`), seul fichier à modifier
> pour changer le comportement de fin de partie ou la fréquence de tick.

---

## Structure du projet

Le code est découpé en modules indépendants, chacun avec sa paire
`.c` / `.h` (header dans `src/include/`), pour que chaque fichier
tienne dans un seul écran et se modifie sans toucher au reste.

```
boggle-pocketbook/
├── src/
│   ├── include/
│   │   ├── game_state.h         types, constantes, état partagé (extern)
│   │   ├── ui_fonts.h           chargement polices + layout écran
│   │   ├── dice.h               table des 16 dés officiels + tirage
│   │   ├── game_logic.h         règles du jeu (grille, sélection, score, Q/Qu)
│   │   ├── timer.h              chronomètre de partie
│   │   ├── screen_mode_select.h écran de choix du mode
│   │   ├── screen_game.h        écran de partie (HUD, grille, mots)
│   │   ├── screen_multi_end.h   écran de fin de partie multijoueur
│   │   └── input.h              routage des événements tactiles/clavier
│   ├── game_state.c       ← définition unique de l'état global `g`
│   ├── ui_fonts.c         ← OpenFont/CloseFont, calcul SW/SH/CELL_SIZE
│   ├── dice.c             ← 16 dés officiels Boggle FR + tirage (Fisher-Yates)
│   ├── game_logic.c       ← logique pure, aucun appel de dessin
│   ├── timer.c            ← callback SetHardTimer, fin de partie
│   ├── screen_mode_select.c
│   ├── screen_game.c
│   ├── screen_multi_end.c
│   ├── input.c            ← dispatch EVT_POINTERUP / EVT_KEYPRESS
│   └── main.c             ← main_handler minimal + main()
├── CMakeLists.txt    ← build avec CMake + toolchain SDK (file(GLOB) auto)
├── Makefile          ← build direct sans CMake (1 objet par module)
└── README.md         ← ce fichier
```

### Qui dépend de qui

```
main.c
 ├─► game_state.h   (cur_screen, EVT_*)
 ├─► ui_fonts.h      (fonts_load/free, layout_compute)
 ├─► screen_mode_select.h / screen_game.h / screen_multi_end.h  (draw_*)
 └─► input.h         (input_handle_pointerup/keypress)

input.c
 ├─► game_logic.h    (game_start, validate_word, handle_cell_touch...)
 └─► screen_*.h      (pour redessiner après une action)

timer.c
 ├─► screen_game.h       (draw_hud, pour le tick partiel)
 └─► screen_multi_end.h  (draw_multi_end, à 0:00 en mode multi)

game_logic.c
 ├─► timer.h         (game_timer_start, appelé depuis game_start)
 └─► dice.h          (dice_roll_grid, appelé depuis game_start)

dice.c
 └─► game_state.h    (écrit g.grid, lit GRID_SIZE)

screen_*.c, game_logic.c, timer.c, dice.c
 └─► game_state.h    (lecture/écriture de `g`, `cur_screen`, layout)
```

`game_state.h` est le seul header inclus par (presque) tout le monde :
c'est le contrat de données partagé. Aucun module de rendu (`screen_*`)
n'est inclus par `game_logic.c`, qui reste de la logique pure sans
aucun appel `Draw*`/`Fill*` — cette séparation permet par exemple de
tester `game_logic.c` indépendamment du rendu (voir plus bas).

### Pourquoi ce découpage

- **`game_state`** isole les données partagées dans un seul fichier
  `.c` : une seule définition de chaque variable globale, pas de
  risque de symbole dupliqué à l'édition de liens.
- **`dice`** isole la table des 16 dés officiels et l'algorithme de
  tirage : remplacer la répartition (ex. passer à un Boggle 5×5 avec
  25 dés) ou changer la langue ne touche que ce fichier.
- **`game_logic`** ne contient aucun appel graphique : c'est le seul
  fichier à modifier pour changer les règles (score, validation,
  dictionnaire, adjacence...), et le plus facile à tester isolément.
- **`timer`** isole la seule fonction qui s'exécute *hors* du flux
  normal d'événements InkView (callback asynchrone) — utile à
  identifier en cas de bug lié au rafraîchissement e-ink.
- **`screen_*`** : un fichier par écran affiché à l'utilisateur ;
  ajouter un 4ᵉ écran (ex. un écran de règles) revient à ajouter une
  paire `screen_rules.{c,h}` sans toucher aux autres.
- **`input`** centralise tout le calcul de zones tactiles (boutons,
  cases) en un seul endroit, séparé du dessin — évite la duplication
  des coordonnées de boutons entre "où on les dessine" et "où on
  détecte le tap" (chaque écran garde malgré tout ses formules de
  zone dans les deux fichiers ; voir le commentaire en tête de
  `input.c` à ce sujet).

---

## Prérequis — SDK PocketBook

Télécharger le SDK 6.x depuis :
  https://github.com/pocketbook/SDK_6.3.0

Ou utiliser l'image Docker prête à l'emploi :
```bash
docker pull 5keeve/pocketbook-sdk:6.3.0-b288-v1
```

---

## Compilation

### Avec Make (recommandé pour débuter)
```bash
export PBSDK=$HOME/SDK_6.3.0
make
```

### Avec CMake
```bash
export PBSDK=$HOME/SDK_6.3.0
mkdir build && cd build
cmake .. -DCMAKE_TOOLCHAIN_FILE=$PBSDK/share/cmake/arm_conf.cmake
make
```

### Avec Docker (sans installer le SDK)
```bash
docker run --rm -v $(pwd):/project -w /project \
  5keeve/pocketbook-sdk:6.3.0-b288-v1 \
  sh -c 'arm-obreey-linux-gnueabi-gcc -Isrc/include src/*.c \
         -o boggle.app -linkview -lm'
```

Vérifier que le binaire est bien ARM :
```bash
file boggle.app
# → ELF 32-bit LSB executable, ARM, EABI5 …
```

---

## Vérifier la logique sans la liseuse (tests hôte)

Comme `game_logic.c`, `timer.c`, etc. n'appellent jamais directement
le matériel PocketBook au-delà des fonctions InkView déclarées dans
`inkview.h`, on peut compiler le projet contre un **stub** (de simples
fonctions vides remplaçant `DrawString`, `FillArea`, `SetHardTimer`...)
pour vérifier toute la logique métier sur sa machine de développement,
sans cross-compiler ni avoir de liseuse sous la main :

```bash
# 1. Écrire un inkview.h minimal (types + signatures des fonctions
#    utilisées) et un .c fournissant des implémentations no-op.
# 2. Compiler tous les modules + le stub ensemble :
gcc -Wall -Wextra -Isrc/include -Istub \
    src/*.c stub/inkview_stub.c -o boggle_test -lm

# 3. Ou bien, pour tester uniquement la logique (sans main.c),
#    remplacer main.c par un petit programme de test qui appelle
#    directement game_start(), handle_cell_touch(), validate_word(),
#    game_timer_callback()... et vérifie les invariants avec assert().
```

C'est la méthode utilisée pour valider cette v3 modulaire avant
livraison : un scénario complet (choix du mode, sélection de cases,
construction du digraphe QU, validation, détection de doublon, fin de
timer en solo et en multi, masquage de la grille, navigation par le
bouton Mode) a été rejoué via ces fonctions et vérifié par `assert()`.

Le tirage de `dice.c` a en plus été vérifié statistiquement : sur
plusieurs centaines de tirages, chaque grille générée admet une
bijection complète avec les 16 dés officiels (vérifiée par
backtracking — un algorithme glouton naïf peut donner de faux
négatifs sur ce type de couplage), et aucune grille ne contient plus
d'un Q ou d'un Z.

---

## Déploiement sur la liseuse

1. Connecter la liseuse en USB (mode stockage de masse)
2. Copier `boggle.app` dans `/mnt/ext1/applications/boggle.app`
3. Déconnecter et lancer depuis le menu Applications

Ou via SSH (si dropbear installé) :
```bash
scp boggle.app root@192.168.1.X:/mnt/ext1/applications/boggle.app
```

---

## Pour aller plus loin

### Dictionnaire de mots valides
La validation actuelle (`word_is_valid` dans **`src/game_logic.c`**)
accepte tout mot ≥ 3 lettres. Pour un vrai dictionnaire, ajouter le
chargement et la recherche dans ce même fichier :

```c
// Charger un fichier dictionnaire trié
static char dict[50000][16];
static int  dict_size = 0;

void load_dict(void) {
    FILE *f = fopen("/mnt/ext1/applications/boggle.dict", "r");
    if (!f) return;
    while (fgets(dict[dict_size], 16, f) && dict_size < 50000) {
        // Supprimer le \n final
        dict[dict_size][strcspn(dict[dict_size], "\n")] = '\0';
        // Mettre en majuscules
        for (char *p = dict[dict_size]; *p; p++) *p = toupper(*p);
        dict_size++;
    }
    fclose(f);
}

// Recherche dichotomique
int word_in_dict(const char *w) {
    int lo = 0, hi = dict_size - 1;
    while (lo <= hi) {
        int mid = (lo + hi) / 2;
        int cmp = strcmp(dict[mid], w);
        if (cmp == 0) return 1;
        if (cmp < 0) lo = mid + 1; else hi = mid - 1;
    }
    return 0;
}
```

### Nouvelle partie
Déjà implémenté en v2 : le bouton "Nouvelle partie" de l'écran
`SCREEN_MULTI_END` appelle directement `game_start(MODE_MULTI)` puis
`draw_game()`. Pour ajouter ce bouton en mode solo également, dupliquer
ce schéma dans `draw_game()` / le routage `EVT_POINTERUP`.

### Modes de mise à jour de l'écran
- `FullUpdate()` : qualité optimale (environ 300 ms, fantômes effacés)
- `PartialUpdate(x,y,w,h)` : rapide mais peut laisser des fantômes
- `SoftUpdate()` : intermédiaire, plein écran

Pour un jeu, utiliser `PartialUpdate` sur les zones qui changent
(grille, HUD) et `FullUpdate` sur les transitions de page.

---

## Ressources

- SDK & exemples : https://github.com/pmartin/pocketbook-demo
- SDK Docker     : https://github.com/Skeeve/SDK_6.3.0
- Forum MobileRead : https://www.mobileread.com/forums/forumdisplay.php?f=225
- Headers inkview.h : https://github.com/blchinezu/pocketbook-sdk
- Répartition des lettres sur les dés (source de `dice.c`) :
  http://baggle.org/regles.php
