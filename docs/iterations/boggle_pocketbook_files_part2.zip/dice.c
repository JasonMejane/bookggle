/**
 * dice.c — Table des 16 dés du Boggle 4×4 et tirage de la grille.
 *
 * Source de la répartition des lettres :
 *   http://baggle.org/regles.php  (section "Tirages possibles")
 */

#include "dice.h"
#include "game_state.h"
#include <stdlib.h>
#include <string.h>

/*
 * Les 16 dés officiels du Boggle 4×4, chacun avec ses 6 faces.
 * Un dé = une ligne. L'ordre des dés dans ce tableau n'a aucune
 * importance : ils sont mélangés à chaque tirage (voir dice_roll_grid).
 */
static const char DICE[DICE_COUNT][DICE_FACES] = {
    {'E','T','U','K','N','O'},
    {'E','V','G','T','I','N'},
    {'D','E','C','A','M','P'},
    {'I','E','L','R','U','W'},
    {'E','H','I','F','S','E'},
    {'R','E','C','A','L','S'},
    {'E','N','T','D','O','S'},
    {'O','F','X','R','I','A'},
    {'N','A','V','E','D','Z'},
    {'E','I','O','A','T','A'},
    {'G','L','E','N','Y','U'},
    {'B','M','A','Q','J','O'},
    {'T','L','I','B','R','A'},
    {'S','P','U','L','T','E'},
    {'A','I','M','S','O','R'},
    {'E','N','H','R','I','S'},
};

/*
 * Mélange un tableau d'indices [0..DICE_COUNT-1] par l'algorithme de
 * Fisher-Yates, pour simuler l'ordre aléatoire des dés dans la boîte
 * une fois secouée.
 */
static void shuffle_indices(int *order, int n) {
    for (int i = n - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        int tmp = order[i];
        order[i] = order[j];
        order[j] = tmp;
    }
}

void dice_roll_grid(void) {
    int order[DICE_COUNT];
    for (int i = 0; i < DICE_COUNT; i++) order[i] = i;
    shuffle_indices(order, DICE_COUNT);

    /* Le dé order[k] tombe dans la case k (parcours ligne par ligne),
       et on tire une face au hasard parmi ses 6 lettres. */
    for (int k = 0; k < DICE_COUNT; k++) {
        int r = k / GRID_SIZE;
        int c = k % GRID_SIZE;
        const char *die = DICE[order[k]];
        g.grid[r][c] = die[rand() % DICE_FACES];
    }
}
