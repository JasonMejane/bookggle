/**
 * timer.c — Gestion du chronomètre de partie.
 */

#include "timer.h"
#include "game_state.h"
#include "screen_game.h"
#include "screen_multi_end.h"
#include <stdio.h>

void game_timer_start(void) {
    SetHardTimer("BoggleTimer", game_timer_callback, 1000);
}

void game_timer_callback(int id) {
    (void)id;
    if (g.game_over) return;

    g.time_left--;

    if (g.time_left <= 0) {
        g.time_left = 0;
        g.game_over = 1;

        if (g.mode == MODE_MULTI) {
            /* Masquer la grille immédiatement */
            cur_screen = SCREEN_MULTI_END;
            FillArea(0, 0, SW, SH, WHITE);
            draw_multi_end();
            FullUpdate();
        } else {
            char msg[96];
            snprintf(msg, sizeof(msg),
                     "Temps ecoule !\nScore final : %d point%s",
                     g.score, g.score > 1 ? "s" : "");
            Message(ICON_INFORMATION, "Partie terminee", msg, 5000);
        }
        return;
    }

    /* Mise à jour partielle du HUD uniquement (économise les cycles e-ink) */
    draw_hud();
    PartialUpdate(0, 0, SW, SH / 5);
}
