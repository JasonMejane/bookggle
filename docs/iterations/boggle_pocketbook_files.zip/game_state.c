/**
 * game_state.c — Définition unique de l'état global du jeu.
 *
 * Toutes les variables déclarées `extern` dans game_state.h sont
 * définies ici, une seule fois, pour éviter les définitions multiples
 * à l'édition de liens.
 */

#include "game_state.h"

const char LETTERS[] =
    "AAAAAABBCCDDDEEEEEEEEEEFFFGGHHIIIIIIJKLLLLL"
    "MMMNNNNNNOOOOOOPPQRRRRRRSSSSSSTTTTTTTUUUUUVVWXYZ";

GameState g;
Screen    cur_screen = SCREEN_MODE_SELECT;

ifont *font_title  = NULL;
ifont *font_large  = NULL;
ifont *font_medium = NULL;
ifont *font_small  = NULL;

int SW, SH;
int CELL_SIZE, GRID_X, GRID_Y;

int mode_btn_x, mode_btn_y, mode_btn_w, mode_btn_h;
