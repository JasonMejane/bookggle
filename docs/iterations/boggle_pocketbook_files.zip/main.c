/**
 * main.c — Point d'entrée de l'application Boggle PocketBook.
 *
 * Ce fichier est volontairement minimal : il ne contient que la
 * boucle d'événements InkView (`main_handler`) et le `main()`.
 * Toute la logique métier et le rendu vivent dans des modules dédiés :
 *
 *   game_state.{c,h}        état global partagé (g, cur_screen, layout)
 *   ui_fonts.{c,h}          chargement polices + calcul layout écran
 *   game_logic.{c,h}        règles du jeu (grille, sélection, score, Q/Qu)
 *   timer.{c,h}             chronomètre de partie
 *   screen_mode_select.{c,h} écran de choix du mode
 *   screen_game.{c,h}        écran de partie (HUD, grille, mots)
 *   screen_multi_end.{c,h}   écran de fin de partie multijoueur
 *   input.{c,h}              routage des événements tactiles/clavier
 *
 * MODES :
 *   Solo        — saisie tactile des mots, score en temps réel
 *   Multijoueur — grille visible pendant le timer, puis MASQUÉE
 *                 quand le temps arrive à 0 (les joueurs ont noté
 *                 leurs mots sur papier, on compare ensuite).
 *
 * NAVIGATION :
 *   - Démarrage → écran de choix du mode
 *   - Pendant la partie → bouton "Mode" (HUD, haut-droit) ou KEY_BACK
 *     ramène à l'écran de choix
 *
 * SPÉCIFICITÉ FR :
 *   La case Q affiche "Qu" et contribue le digraphe "QU" dans le mot.
 *
 * Compilation : voir Makefile / CMakeLists.txt (build multi-fichiers).
 */

#include "inkview.h"
#include "game_state.h"
#include "ui_fonts.h"
#include "screen_mode_select.h"
#include "screen_game.h"
#include "screen_multi_end.h"
#include "input.h"
#include <stdlib.h>
#include <time.h>

/* ═══════════════════════════════════════════════════════════════════
   GESTIONNAIRE D'ÉVÉNEMENTS PRINCIPAL
   ═══════════════════════════════════════════════════════════════════ */

static int main_handler(int type, int par1, int par2) {

    switch (type) {

    /* ── Initialisation ── */
    case EVT_INIT:
        srand((unsigned int)time(NULL));
        fonts_load();
        layout_compute();
        cur_screen = SCREEN_MODE_SELECT;
        break;

    /* ── Redessiner ── */
    case EVT_SHOW:
        switch (cur_screen) {
        case SCREEN_MODE_SELECT: draw_mode_select(); break;
        case SCREEN_GAME:        draw_game();        break;
        case SCREEN_MULTI_END:   draw_multi_end(); FullUpdate(); break;
        }
        break;

    /* ── Relâchement du doigt ── */
    case EVT_POINTERUP:
        input_handle_pointerup(par1, par2);
        break;

    /* ── Bouton physique ── */
    case EVT_KEYPRESS:
        input_handle_keypress(par1);
        break;

    /* ── Nettoyage avant fermeture ── */
    case EVT_EXIT:
        fonts_free();
        break;

    default:
        break;
    }
    return 0;
}

/* ═══════════════════════════════════════════════════════════════════
   POINT D'ENTRÉE
   ═══════════════════════════════════════════════════════════════════ */

int main(int argc, char **argv) {
    (void)argc; (void)argv;
    InkViewMain(main_handler);
    return 0;
}
