/**
 * screen_game.c — Rendu de l'écran de partie (HUD, grille, mots).
 */

#include "screen_game.h"
#include "game_state.h"
#include "game_logic.h"
#include <stdio.h>
#include <string.h>

/* ═══════════════════════════════════════════════════════════════════
   HUD (commun aux deux modes)
   ═══════════════════════════════════════════════════════════════════ */

void draw_hud(void) {
    int hud_h = SH / 5;
    FillArea(0, 0, SW, hud_h, WHITE);

    /* Titre avec indicateur de mode */
    SetFont(font_title, BLACK);
    const char *title = (g.mode == MODE_MULTI) ? "BOGGLE Multi" : "BOGGLE Solo";
    DrawTextRect(0, 6, SW, 44, title, ALIGN_CENTER);

    /* Timer — en gris foncé sous les 30 dernières secondes */
    char ts[16];
    snprintf(ts, sizeof(ts), "%02d:%02d", g.time_left / 60, g.time_left % 60);
    SetFont(font_large, g.time_left <= 30 ? DGRAY : BLACK);
    DrawTextRect(0, 54, SW, 36, ts, ALIGN_CENTER);

    /* Score (solo seulement) */
    if (g.mode == MODE_SOLO) {
        char ss[32];
        snprintf(ss, sizeof(ss), "Score : %d", g.score);
        SetFont(font_small, BLACK);
        DrawTextRect(0, 94, SW / 2, 22, ss, ALIGN_CENTER);
    }

    /* Bouton "Mode" (haut-droit) — coordonnées exportées pour input.c */
    mode_btn_w = 80; mode_btn_h = 28;
    mode_btn_x = SW - mode_btn_w - 6;
    mode_btn_y = 8;
    DrawRect(mode_btn_x, mode_btn_y, mode_btn_w, mode_btn_h, DGRAY);
    SetFont(font_small, DGRAY);
    DrawTextRect(mode_btn_x, mode_btn_y + 4,
                 mode_btn_w, mode_btn_h, "Mode", ALIGN_CENTER);

    DrawLine(0, hud_h - 2, SW, hud_h - 2, BLACK);
}

/* ═══════════════════════════════════════════════════════════════════
   GRILLE 4×4
   ═══════════════════════════════════════════════════════════════════ */

void draw_grid(void) {
    for (int r = 0; r < GRID_SIZE; r++) {
        for (int c = 0; c < GRID_SIZE; c++) {
            int idx = r * GRID_SIZE + c;
            int x = GRID_X + c * CELL_SIZE;
            int y = GRID_Y + r * CELL_SIZE;

            /* Fond : gris clair si case sélectionnée */
            int bg = WHITE, order = -1;
            for (int s = 0; s < g.sel_count; s++) {
                if (g.selected[s] == idx) {
                    bg = LGRAY; order = s; break;
                }
            }
            FillArea(x + 2, y + 2, CELL_SIZE - 4, CELL_SIZE - 4, bg);
            DrawRect(x + 2, y + 2, CELL_SIZE - 4, CELL_SIZE - 4, BLACK);

            /* Numéro d'ordre de sélection (solo seulement) */
            if (order >= 0 && g.mode == MODE_SOLO) {
                char os[4];
                snprintf(os, sizeof(os), "%d", order + 1);
                SetFont(font_small, DGRAY);
                DrawString(x + CELL_SIZE - 20, y + 6, os);
            }

            /* Label : "Qu" pour Q (police réduite), lettre seule sinon */
            const char *lbl = cell_label(r, c);
            if (g.grid[r][c] == 'Q') SetFont(font_medium, BLACK);
            else                       SetFont(font_large, BLACK);

            int lw = StringWidth(lbl);
            DrawString(x + (CELL_SIZE - lw) / 2,
                       y + (CELL_SIZE - 30) / 2, lbl);
        }
    }
}

/* ═══════════════════════════════════════════════════════════════════
   BARRE DU MOT EN COURS (solo)
   ═══════════════════════════════════════════════════════════════════ */

void draw_word_bar(void) {
    int bar_y = GRID_Y + GRID_SIZE * CELL_SIZE + 14;
    FillArea(0, bar_y, SW, SH - bar_y, WHITE);

    /* Mot en cours */
    char display[MAX_WORD_LEN + 6];
    snprintf(display, sizeof(display), "> %s",
             g.sel_count > 0 ? g.current_word : "...");
    SetFont(font_medium, BLACK);
    DrawTextRect(0, bar_y + 8, SW - 114, 36, display, ALIGN_CENTER);

    /* Bouton Valider */
    int bx = SW - 110, by = bar_y + 6;
    DrawRect(bx, by, 100, 36, BLACK);
    SetFont(font_medium, BLACK);
    DrawTextRect(bx, by + 6, 100, 36, "Valider", ALIGN_CENTER);

    /* Bouton Effacer */
    DrawRect(bx, by + 44, 100, 32, DGRAY);
    SetFont(font_small, DGRAY);
    DrawTextRect(bx, by + 50, 100, 32, "Effacer", ALIGN_CENTER);
}

/* ═══════════════════════════════════════════════════════════════════
   LISTE DES MOTS TROUVÉS (solo)
   ═══════════════════════════════════════════════════════════════════ */

void draw_found_words(void) {
    int lx = GRID_X + GRID_SIZE * CELL_SIZE + 10;
    int ly = GRID_Y;
    int lw = SW - lx - 6;

    char hdr[32];
    snprintf(hdr, sizeof(hdr), "Mots (%d)", g.word_count);
    SetFont(font_small, BLACK);
    DrawTextRect(lx, ly, lw, 22, hdr, ALIGN_LEFT);

    int y = ly + 26;
    int start = (g.word_count > 14) ? g.word_count - 14 : 0;
    for (int i = start; i < g.word_count; i++) {
        int wl = (int)strlen(g.found_words[i]);
        char line[MAX_WORD_LEN + 8];
        snprintf(line, sizeof(line), "%s +%d",
                 g.found_words[i], score_for_word(wl));
        DrawString(lx, y, line);
        y += 20;
        if (y > SH - 20) break;
    }
}

/* ═══════════════════════════════════════════════════════════════════
   ÉCRAN DE JEU COMPLET
   ═══════════════════════════════════════════════════════════════════ */

void draw_game(void) {
    FillArea(0, 0, SW, SH, WHITE);
    draw_hud();
    draw_grid();

    if (g.mode == MODE_SOLO) {
        draw_word_bar();
        draw_found_words();
    } else {
        /* Mode multi : instruction sous la grille */
        int msg_y = GRID_Y + GRID_SIZE * CELL_SIZE + 16;
        SetFont(font_small, DGRAY);
        DrawTextRect(0, msg_y, SW, 28,
            "Notez vos mots — la grille disparait a 0:00",
            ALIGN_CENTER);
    }
    FullUpdate();
}
