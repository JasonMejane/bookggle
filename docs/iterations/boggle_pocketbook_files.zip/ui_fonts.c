/**
 * ui_fonts.c — Chargement des polices et calcul du layout écran.
 */

#include "ui_fonts.h"
#include "game_state.h"

void fonts_load(void) {
    font_title  = OpenFont("LiberationSans", 38, 1);
    font_large  = OpenFont("LiberationSans", 30, 1);
    font_medium = OpenFont("LiberationSans", 22, 1);
    font_small  = OpenFont("LiberationSans", 16, 1);
}

void fonts_free(void) {
    if (font_title)  { CloseFont(font_title);  font_title  = NULL; }
    if (font_large)  { CloseFont(font_large);  font_large  = NULL; }
    if (font_medium) { CloseFont(font_medium); font_medium = NULL; }
    if (font_small)  { CloseFont(font_small);  font_small  = NULL; }
}

void layout_compute(void) {
    SW = ScreenWidth();
    SH = ScreenHeight();
    CELL_SIZE = (SW * 60 / 100) / GRID_SIZE;
    GRID_X    = (SW - CELL_SIZE * GRID_SIZE) / 2;
    GRID_Y    = SH / 5;
}
