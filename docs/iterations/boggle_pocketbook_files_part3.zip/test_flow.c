/**
 * test_flow.c — Scénario complet de jeu, de bout en bout.
 *
 * Ne teste pas le rendu graphique (les fonctions Draw... et Fill...
 * sont des no-op fournies par stub/inkview_stub.c) : ce test vérifie la
 * LOGIQUE — navigation entre écrans, sélection de cases, construction
 * du digraphe Q→QU, validation/score d'un mot, détection de doublon,
 * comportement du timer en solo et en multijoueur, et les actions des
 * boutons (Mode, Back).
 *
 * Il appelle les vraies fonctions publiques des modules (game_start,
 * handle_cell_touch, validate_word, game_timer_callback,
 * input_handle_pointerup, input_handle_keypress...), pas des copies
 * ni des doublures : un échec ici signale un vrai bug dans src/.
 *
 * NOTE — on_timer_tick() : timer.c (logique pure du chronomètre)
 * enregistre auprès d'InkView un adaptateur on_timer_tick(int), dont
 * l'implémentation "réelle" vit dans src/main.c (elle y interprète le
 * TimerTickResult pour déclencher le bon rendu). Comme ce binaire de
 * test ne compile pas main.c (qui a son propre main()), une version
 * minimale de on_timer_tick() est fournie ci-dessous : elle se
 * contente d'appeler game_timer_callback() sans rien dessiner,
 * suffisant pour le link et pour les scénarios de ce fichier, qui
 * appellent de toute façon game_timer_callback() directement plutôt
 * que de passer par le timer matériel simulé.
 *
 * COMPILATION (depuis la racine du projet) :
 *   gcc -Wall -Wextra -Isrc/include -Itests/stub \
 *       src/game_state.c src/ui_fonts.c src/game_logic.c src/timer.c \
 *       src/dice.c src/screen_mode_select.c src/screen_game.c \
 *       src/screen_multi_end.c src/input.c \
 *       tests/stub/inkview_stub.c tests/test_flow.c \
 *       -o /tmp/test_flow -lm
 *   /tmp/test_flow
 *
 * Ou plus simplement, depuis tests/ :  make test-flow
 *
 * Code de sortie : 0 si tous les assert() passent, sinon le programme
 * s'arrête (abort) sur le premier assert() qui échoue — le message
 * affiché juste avant indique quel scénario était en cours.
 */

#include "game_state.h"
#include "ui_fonts.h"
#include "game_logic.h"
#include "timer.h"
#include "screen_mode_select.h"
#include "screen_game.h"
#include "screen_multi_end.h"
#include "input.h"
#include <stdio.h>
#include <assert.h>
#include <string.h>

/* Implémentation minimale requise par timer.c (voir game_timer_start)
   pour que l'édition de liens réussisse — ce binaire de test n'inclut
   pas main.c, qui fournit la vraie version (avec rendu). */
void on_timer_tick(int id) {
    (void)game_timer_callback(id);
}

int main(void) {
    /* ── Scénario 1 : EVT_INIT ───────────────────────────────────── */
    fonts_load();
    layout_compute();
    cur_screen = SCREEN_MODE_SELECT;
    printf("[OK] init : SW=%d SH=%d CELL=%d\n", SW, SH, CELL_SIZE);

    /* ── Scénario 2 : choix du mode Solo via un tap simulé ──────── */
    int bw = SW * 2 / 3, bh = 64, bx = (SW - bw) / 2;
    int solo_y = SH * 2 / 5;
    input_handle_pointerup(bx + bw / 2, solo_y + bh / 2);
    assert(cur_screen == SCREEN_GAME);
    assert(g.mode == MODE_SOLO);
    printf("[OK] selection mode solo -> SCREEN_GAME, mode=%d\n", g.mode);

    /* ── Scénario 3 : sélection de cases + digraphe Q->QU ───────── */
    /* Grille déterministe pour ce test : A,B,C,D / E,F,G,H / ...
       avec un Q forcé en (0,0) pour vérifier le digraphe. */
    for (int r = 0; r < GRID_SIZE; r++)
        for (int c = 0; c < GRID_SIZE; c++)
            g.grid[r][c] = (char)('A' + r * GRID_SIZE + c);
    g.grid[0][0] = 'Q';

    int x0 = GRID_X + 0 * CELL_SIZE + CELL_SIZE / 2;
    int y0 = GRID_Y + 0 * CELL_SIZE + CELL_SIZE / 2;
    int x1 = GRID_X + 1 * CELL_SIZE + CELL_SIZE / 2;
    int y1 = GRID_Y + 0 * CELL_SIZE + CELL_SIZE / 2;

    handle_cell_touch(x0, y0);
    printf("[OK] touch case0 (Q) -> current_word='%s'\n", g.current_word);
    assert(strcmp(g.current_word, "QU") == 0);

    handle_cell_touch(x1, y1);
    printf("[OK] touch case1 (B) -> current_word='%s'\n", g.current_word);
    assert(strcmp(g.current_word, "QUB") == 0);

    /* ── Scénario 4 : validation d'un mot (score + liste) ───────── */
    int word_count_before = g.word_count;
    int score_before = g.score;
    validate_word();
    assert(g.word_count == word_count_before + 1);
    assert(g.score == score_before + score_for_word(3));
    assert(g.sel_count == 0);
    printf("[OK] validate_word -> word_count=%d score=%d\n",
           g.word_count, g.score);

    /* ── Scénario 5 : détection de doublon ──────────────────────── */
    handle_cell_touch(x0, y0);
    handle_cell_touch(x1, y1);
    int wc2 = g.word_count;
    validate_word();
    assert(g.word_count == wc2); /* pas d'ajout, doublon détecté */
    printf("[OK] doublon detecte, word_count inchange (%d)\n", g.word_count);

    /* ── Scénario 6 : timer en mode solo jusqu'à 0:00 ───────────── */
    /* game_timer_callback() est maintenant une fonction de logique
       pure (timer.c) qui ne dessine rien : elle retourne un
       TimerTickResult que l'appelant (ici le test, normalement
       on_timer_tick() dans main.c) interprète lui-même. */
    g.time_left = 2;
    g.game_over = 0;
    TimerTickResult r1 = game_timer_callback(0);
    assert(r1 == TIMER_TICK_RUNNING);
    assert(g.time_left == 1 && !g.game_over);
    TimerTickResult r2 = game_timer_callback(0);
    assert(r2 == TIMER_TICK_ENDED_SOLO);
    assert(g.time_left == 0 && g.game_over);
    printf("[OK] timer solo -> TIMER_TICK_ENDED_SOLO, game_over=%d a 0:00\n",
           g.game_over);

    /* ── Scénario 7 : timer en mode multi -> grille masquée ─────── */
    game_start(MODE_MULTI);
    assert(cur_screen == SCREEN_GAME);
    assert(g.mode == MODE_MULTI);
    g.time_left = 1;
    TimerTickResult r3 = game_timer_callback(0);
    assert(r3 == TIMER_TICK_ENDED_MULTI);
    assert(g.time_left == 0 && g.game_over);
    assert(cur_screen == SCREEN_MULTI_END);
    printf("[OK] timer multi -> TIMER_TICK_ENDED_MULTI, "
           "cur_screen=SCREEN_MULTI_END (grille masquee)\n");

    /* ── Scénario 8 : tactile ignoré en mode multi ──────────────── */
    game_start(MODE_MULTI);
    handle_cell_touch(x0, y0);
    assert(g.sel_count == 0);
    printf("[OK] tactile ignore en mode multi (sel_count=%d)\n", g.sel_count);

    /* ── Scénario 9 : bouton "Mode" du HUD ramène à la sélection ── */
    draw_game(); /* fixe mode_btn_x/y/w/h pour ce tap */
    input_handle_pointerup(mode_btn_x + mode_btn_w / 2,
                            mode_btn_y + mode_btn_h / 2);
    assert(cur_screen == SCREEN_MODE_SELECT);
    printf("[OK] bouton Mode -> retour SCREEN_MODE_SELECT\n");

    /* ── Scénario 10 : touche Back depuis l'écran d'accueil ─────── */
    input_handle_keypress(KEY_BACK);
    printf("[OK] KEY_BACK depuis mode_select traite sans crash\n");

    fonts_free();
    printf("\n=== TOUS LES TESTS LOGIQUES SONT PASSES (10/10) ===\n");
    return 0;
}
