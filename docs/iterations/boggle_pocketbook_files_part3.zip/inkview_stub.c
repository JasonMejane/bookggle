/**
 * inkview_stub.c (STUB DE TEST)
 *
 * Implémentations factices ("no-op") de toutes les fonctions
 * déclarées dans le inkview.h de test (stub/inkview.h). Aucune
 * d'elles ne dessine ou n'affiche réellement quoi que ce soit : le
 * but est uniquement de fournir un corps valide à chaque symbole pour
 * que l'édition de liens (gcc ... -o binaire) réussisse, afin de
 * pouvoir exécuter la logique du jeu (les modules de src/) sur une
 * machine de développement classique.
 *
 * ScreenWidth()/ScreenHeight() renvoient une résolution PocketBook
 * plausible (758×1024, proche d'une Touch Lux / Basic) pour que
 * layout_compute() calcule des valeurs de CELL_SIZE/GRID_X/GRID_Y
 * réalistes pendant les tests.
 */

#include "inkview.h"

int ScreenWidth(void)  { return 758; }
int ScreenHeight(void) { return 1024; }

ifont *OpenFont(const char *name, int size, int bold) {
    (void)name; (void)size; (void)bold;
    return (ifont *)1;  /* pointeur non-NULL factice */
}

void CloseFont(ifont *font) { (void)font; }
void SetFont(ifont *font, int color) { (void)font; (void)color; }

void FillArea(int x, int y, int w, int h, int color) {
    (void)x; (void)y; (void)w; (void)h; (void)color;
}

void DrawRect(int x, int y, int w, int h, int color) {
    (void)x; (void)y; (void)w; (void)h; (void)color;
}

void DrawLine(int x1, int y1, int x2, int y2, int color) {
    (void)x1; (void)y1; (void)x2; (void)y2; (void)color;
}

void DrawString(int x, int y, const char *text) {
    (void)x; (void)y; (void)text;
}

void DrawTextRect(int x, int y, int w, int h, const char *text, int align) {
    (void)x; (void)y; (void)w; (void)h; (void)text; (void)align;
}

int StringWidth(const char *text) {
    (void)text;
    return 20; /* largeur factice mais non nulle */
}

void FullUpdate(void) {}
void PartialUpdate(int x, int y, int w, int h) {
    (void)x; (void)y; (void)w; (void)h;
}

void Message(int icon, const char *title, const char *text, int ms) {
    (void)icon; (void)title; (void)text; (void)ms;
}

void CloseApp(void) {}

/* Ne lance volontairement PAS de vraie boucle d'événements :
   InkViewMain() ne fait rien dans ce stub. C'est voulu — les tests
   appellent directement les fonctions des modules (game_start(),
   handle_cell_touch()...) plutôt que de passer par cette boucle. */
void InkViewMain(iv_handler handler) { (void)handler; }

int SetHardTimer(const char *name, iv_timer_handler handler, int ms) {
    (void)name; (void)handler; (void)ms;
    return 1; /* identifiant de timer factice */
}
