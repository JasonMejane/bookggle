/**
 * inkview.h (STUB DE TEST — ne pas utiliser pour un build de production)
 *
 * Réimplémentation minimale des types et signatures de la bibliothèque
 * InkView réellement utilisés par les modules de src/, dans le seul
 * but de pouvoir COMPILER et EXÉCUTER le projet sur une machine de
 * développement classique (Linux/macOS), sans le SDK ARM PocketBook
 * ni de liseuse physique.
 *
 * Ce fichier ne doit JAMAIS être copié dans src/ ni utilisé pour
 * produire le binaire .app final : pour le vrai build PocketBook,
 * c'est le inkview.h fourni par le SDK officiel
 * (https://github.com/pocketbook/SDK_6.3.0) qui doit être utilisé
 * — voir le Makefile / CMakeLists.txt à la racine du projet.
 *
 * Les déclarations ci-dessous se limitent strictement aux fonctions
 * et constantes effectivement utilisées par les fichiers de src/ et
 * tests/ (vérifié par compilation : tout symbole InkView manquant
 * ferait échouer le link).
 */

#ifndef INKVIEW_H
#define INKVIEW_H

typedef void* ifont;
typedef int  (*iv_handler)(int, int, int);
typedef void (*iv_timer_handler)(int);

/* Types d'événements InkView utilisés par main.c */
#define EVT_INIT       0
#define EVT_SHOW       1
#define EVT_EXIT       2
#define EVT_POINTERUP  3
#define EVT_KEYPRESS   4

/* Touches physiques */
#define KEY_BACK       1

/* Couleurs e-ink (4 niveaux de gris suffisent à ce projet) */
#define BLACK          0
#define WHITE          1
#define LGRAY          2
#define DGRAY          3

/* Alignement de texte pour DrawTextRect */
#define ALIGN_CENTER   0
#define ALIGN_LEFT     1

/* Icônes pour Message() */
#define ICON_INFORMATION 0
#define ICON_WARNING     1

/* ── Écran & polices ──────────────────────────────────────────────── */
int    ScreenWidth(void);
int    ScreenHeight(void);
ifont *OpenFont(const char *name, int size, int bold);
void   CloseFont(ifont *font);
void   SetFont(ifont *font, int color);

/* ── Primitives de dessin ─────────────────────────────────────────── */
void   FillArea(int x, int y, int w, int h, int color);
void   DrawRect(int x, int y, int w, int h, int color);
void   DrawLine(int x1, int y1, int x2, int y2, int color);
void   DrawString(int x, int y, const char *text);
void   DrawTextRect(int x, int y, int w, int h, const char *text, int align);
int    StringWidth(const char *text);

/* ── Rafraîchissement e-ink ───────────────────────────────────────── */
void   FullUpdate(void);
void   PartialUpdate(int x, int y, int w, int h);

/* ── Boîtes de dialogue, cycle de vie ─────────────────────────────── */
void   Message(int icon, const char *title, const char *text, int ms);
void   CloseApp(void);
void   InkViewMain(iv_handler handler);

/* ── Timer matériel ───────────────────────────────────────────────── */
int    SetHardTimer(const char *name, iv_timer_handler handler, int ms);

#endif /* INKVIEW_H */
