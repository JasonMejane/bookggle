/**
 * timer.h — Gestion du chronomètre de partie (logique pure).
 *
 * Ce module est responsable UNIQUEMENT de la valeur du timer :
 * démarrage, décompte à chaque tick, détection de fin de partie, et
 * mise à jour de l'état qui en découle (g.game_over, cur_screen pour
 * le mode multi). Il ne dessine jamais rien lui-même — aucun appel
 * Draw..., Fill... ou Message, aucune dépendance aux modules screen_*.
 *
 * C'est à l'appelant de game_timer_callback() (typiquement le point
 * d'orchestration dans main.c) de regarder la valeur retournée par
 * TimerTick et de décider quoi redessiner en conséquence : un tick
 * normal appelle d'ordinaire draw_hud() + PartialUpdate, une fin de
 * partie appelle draw_multi_end() (mode multi) ou affiche un message
 * de score (mode solo). Cette séparation permet de faire évoluer le
 * rendu (nouvel écran de fin, animation, son...) sans jamais toucher
 * à ce fichier, et inversement de changer la durée ou les règles du
 * timer sans toucher au code de rendu.
 */

#ifndef TIMER_H
#define TIMER_H

/*
 * Résultat d'un tick de timer, à consommer par l'appelant pour
 * décider de l'action de rendu appropriée.
 */
typedef enum {
    TIMER_TICK_RUNNING,     /* partie toujours en cours, time_left > 0 */
    TIMER_TICK_ENDED_SOLO,  /* time_left vient d'atteindre 0, mode solo */
    TIMER_TICK_ENDED_MULTI  /* time_left vient d'atteindre 0, mode multi */
} TimerTickResult;

/* (Re)démarre le timer de jeu à raison d'un tick par seconde. */
void game_timer_start(void);

/*
 * Callback appelée par InkView toutes les secondes pendant qu'une
 * partie est en cours. Décrémente g.time_left ; à 0, marque la
 * partie comme terminée (g.game_over = 1) et, en mode multi,
 * bascule cur_screen sur SCREEN_MULTI_END (la grille doit être
 * masquée — c'est au rendu de l'interpréter, pas à ce module).
 *
 * Ne dessine rien : retourne uniquement un statut décrivant ce qui
 * vient de se passer, à l'appelant de déclencher le rendu adapté.
 *
 * NOTE SUR LA SIGNATURE : SetHardTimer (InkView) exige une callback
 * void(*)(int). game_timer_callback() retourne TimerTickResult et ne
 * peut donc pas être passée directement à SetHardTimer. game_timer_start()
 * enregistre à la place un adaptateur, on_timer_tick(int), défini
 * dans main.c : c'est lui qui appelle game_timer_callback() et
 * interprète le résultat pour déclencher le bon rendu (draw_hud +
 * PartialUpdate sur un tick normal, draw_multi_end + FullUpdate ou
 * un Message de score selon le mode en fin de partie).
 */
TimerTickResult game_timer_callback(int id);

/*
 * Adaptateur entre InkView et game_timer_callback(), défini dans
 * main.c. Signature imposée par SetHardTimer (void(*)(int)) : c'est
 * lui qui est réellement enregistré comme callback de timer, et qui
 * consomme le TimerTickResult pour décider du rendu. Déclaré ici
 * (plutôt qu'en extern local dans timer.c) pour documenter
 * explicitement ce contrat entre les deux fichiers.
 */
void on_timer_tick(int id);

#endif /* TIMER_H */
