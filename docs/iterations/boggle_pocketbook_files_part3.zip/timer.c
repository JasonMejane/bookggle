/**
 * timer.c — Gestion du chronomètre de partie (logique pure).
 *
 * Ce module n'inclut volontairement aucun header de rendu
 * (screen_*.h) et n'appelle aucune fonction de dessin InkView
 * (Draw*, Fill*, FullUpdate, PartialUpdate, Message...). Il se limite
 * à la valeur du timer et à l'état qui en découle directement
 * (g.time_left, g.game_over, cur_screen).
 *
 * game_timer_callback() retourne un TimerTickResult plutôt que de
 * rien retourner : sa signature n'est donc PAS celle attendue par
 * SetHardTimer (qui exige void(*)(int)). C'est volontaire — voir
 * timer.h. L'adaptateur qui relie les deux (et qui décide quoi
 * dessiner selon le résultat) vit dans main.c, le point
 * d'orchestration du projet, pas ici.
 */

#include "timer.h"
#include "game_state.h"

void game_timer_start(void) {
    /* L'enregistrement auprès d'InkView se fait avec l'adaptateur
       on_timer_tick() défini dans main.c, pas directement avec
       game_timer_callback() — voir timer.h pour le pourquoi. */
    SetHardTimer("BoggleTimer", on_timer_tick, 1000);
}

TimerTickResult game_timer_callback(int id) {
    (void)id;
    if (g.game_over) return TIMER_TICK_RUNNING;

    g.time_left--;

    if (g.time_left <= 0) {
        g.time_left = 0;
        g.game_over = 1;

        if (g.mode == MODE_MULTI) {
            /* La grille doit être masquée : on bascule l'écran actif,
               mais c'est au code de rendu de redessiner en
               conséquence — ce module ne dessine rien lui-même. */
            cur_screen = SCREEN_MULTI_END;
            return TIMER_TICK_ENDED_MULTI;
        }
        return TIMER_TICK_ENDED_SOLO;
    }

    return TIMER_TICK_RUNNING;
}
