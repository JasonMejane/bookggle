/**
 * test_dice.c — Vérifie que dice_roll_grid() respecte les règles
 * physiques des 16 dés officiels du Boggle 4×4.
 *
 * Deux propriétés sont vérifiées sur un grand nombre de tirages :
 *
 *   1. Bijection exacte lettres<->dés : chaque grille tirée doit
 *      pouvoir s'expliquer par "ce dé a montré cette face" pour les
 *      16 dés, chacun utilisé une seule fois. C'est un problème de
 *      couplage biparti (matching) — voir l'avertissement ci-dessous.
 *
 *   2. Conséquence du point 1 : comme un seul dé porte le Q
 *      (BMAQJO) et un seul porte le Z (NAVEDZ), aucune grille ne
 *      peut légitimement contenir plus d'un Q ou plus d'un Z.
 *
 * ⚠️ PIÈGE RENCONTRÉ EN ÉCRIVANT CE TEST — algorithme glouton invalide
 * ────────────────────────────────────────────────────────────────────
 * Une première version de ce test vérifiait la bijection avec un
 * algorithme GLOUTON : pour chaque lettre tirée, prendre le premier
 * dé disponible qui la porte. Ce test a immédiatement signalé un
 * "échec" sur dice_roll_grid() — alors que l'implémentation était en
 * réalité correcte. La cause : un algorithme glouton peut "consommer"
 * par erreur un dé qui aurait dû être réservé à une lettre plus rare
 * apparaissant plus loin dans la liste (problème classique de
 * couplage biparti, où gourmand ne garantit pas une solution même
 * si elle existe). La correction a consisté à remplacer le glouton
 * par un vrai backtracking (try_assign ci-dessous), qui explore les
 * alternatives et revient en arrière si un choix bloque la suite.
 * Retenir : si ce test échoue après une modification de dice.c,
 * vérifier D'ABORD si la table DICE[] ci-dessous est toujours fidèle
 * à celle de src/dice.c avant de suspecter dice_roll_grid() lui-même.
 *
 * COMPILATION (depuis la racine du projet) :
 *   gcc -Wall -Wextra -O2 -Isrc/include -Itests/stub \
 *       src/game_state.c src/dice.c \
 *       tests/stub/inkview_stub.c tests/test_dice.c \
 *       -o /tmp/test_dice -lm
 *   /tmp/test_dice
 *
 * Ou plus simplement, depuis tests/ :  make test-dice
 */

#include "game_state.h"
#include "dice.h"
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

/*
 * Recopie indépendante de la table officielle des 16 dés (doit rester
 * identique à celle de src/dice.c). Dupliquée ici volontairement,
 * plutôt que réutilisée via un #include, pour que ce test vérifie
 * dice_roll_grid() contre une référence écrite séparément — et non
 * contre sa propre table interne, ce qui ne prouverait rien.
 * Source : http://baggle.org/regles.php
 */
static const char DICE[16][6] = {
    {'E','T','U','K','N','O'},
    {'E','V','G','T','I','N'},
    {'D','E','C','A','M','P'},
    {'I','E','L','R','U','W'},
    {'E','H','I','F','S','E'},
    {'R','E','C','A','L','S'},
    {'E','N','T','D','O','S'},
    {'O','F','X','R','I','A'},
    {'N','A','V','E','D','Z'},
    {'E','I','O','A','T','A'},
    {'G','L','E','N','Y','U'},
    {'B','M','A','Q','J','O'},
    {'T','L','I','B','R','A'},
    {'S','P','U','L','T','E'},
    {'A','I','M','S','O','R'},
    {'E','N','H','R','I','S'},
};

static int letter_on_die(int die_idx, char letter) {
    for (int f = 0; f < 6; f++)
        if (DICE[die_idx][f] == letter) return 1;
    return 0;
}

/*
 * Tente d'assigner un dé distinct à chaque lettre de `letters[0..n)`
 * par backtracking (couplage biparti exact). Voir l'avertissement en
 * tête de fichier sur pourquoi un algorithme glouton ne suffit pas.
 * `used[16]` marque les dés déjà assignés à une lettre précédente.
 * Retourne 1 si une bijection complète existe, 0 sinon.
 */
static int try_assign(const char *letters, int n, int idx, int *used) {
    if (idx == n) return 1; /* toutes les lettres assignées avec succès */
    for (int d = 0; d < 16; d++) {
        if (!used[d] && letter_on_die(d, letters[idx])) {
            used[d] = 1;
            if (try_assign(letters, n, idx + 1, used)) return 1;
            used[d] = 0; /* backtrack : ce choix de dé ne mène à rien */
        }
    }
    return 0;
}

int main(void) {
    srand((unsigned)time(NULL));

    /* ── Propriété 1 : bijection exacte lettres <-> dés ──────────── */
    /* Limité à 500 tirages : le backtracking dans le pire cas est
       exponentiel, 500 reste rapide (quelques dixièmes de seconde)
       tout en couvrant largement assez de tirages pour avoir
       confiance dans l'algorithme. */
    int total_runs = 500;
    for (int run = 0; run < total_runs; run++) {
        dice_roll_grid();

        /* Aplatit la grille en 16 lettres dans l'ordre des cases */
        char letters[16];
        int k = 0;
        for (int r = 0; r < GRID_SIZE; r++)
            for (int c = 0; c < GRID_SIZE; c++)
                letters[k++] = g.grid[r][c];

        int used[16] = {0};
        if (!try_assign(letters, 16, 0, used)) {
            fprintf(stderr,
                "[ECHEC run %d] aucune bijection lettres<->des valide "
                "trouvee pour la grille tiree !\n", run);
            return 1;
        }
    }
    printf("[OK] %d tirages verifies : chaque tirage utilise "
           "exactement les 16 des officiels, une fois chacun, "
           "avec une face valide.\n", total_runs);

    /* ── Propriété 2 : jamais plus d'un Q ni d'un Z par grille ───── */
    int max_q = 0, max_z = 0;
    int runs_qz = 2000;
    for (int run = 0; run < runs_qz; run++) {
        dice_roll_grid();
        int q = 0, z = 0;
        for (int r = 0; r < GRID_SIZE; r++)
            for (int c = 0; c < GRID_SIZE; c++) {
                if (g.grid[r][c] == 'Q') q++;
                if (g.grid[r][c] == 'Z') z++;
            }
        if (q > max_q) max_q = q;
        if (z > max_z) max_z = z;
        assert(q <= 1 && "plus d'un Q dans la grille !");
        assert(z <= 1 && "plus d'un Z dans la grille !");
    }
    printf("[OK] %d tirages : jamais plus d'un Q (max observe=%d) "
           "ni plus d'un Z (max observe=%d) par grille.\n",
           runs_qz, max_q, max_z);

    printf("\n=== TOUS LES TESTS DICE SONT PASSES (2/2) ===\n");
    return 0;
}
