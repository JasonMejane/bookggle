/**
 * test_game_start_dice.c — Vérifie l'intégration game_start() <-> dice.
 *
 * test_dice.c valide dice_roll_grid() de façon isolée. Ce test-ci
 * vérifie qu'en conditions réelles, game_start() (le point d'entrée
 * appelé à chaque nouvelle partie, depuis input.c) utilise bien ce
 * tirage et produit des grilles cohérentes — pas une grille forcée
 * pour le test, mais le vrai chemin de code emprunté en jeu.
 *
 * COMPILATION (depuis la racine du projet) :
 *   gcc -Wall -Wextra -Isrc/include -Itests/stub \
 *       src/game_state.c src/ui_fonts.c src/game_logic.c src/timer.c \
 *       src/dice.c \
 *       tests/stub/inkview_stub.c tests/test_game_start_dice.c \
 *       -o /tmp/test_game_start_dice -lm
 *   /tmp/test_game_start_dice
 *
 * Note : timer.c est de la logique pure (aucune dépendance aux
 * modules screen_*) depuis le découplage timer/rendu — ce test n'a
 * donc plus besoin de lier screen_game.c ni screen_multi_end.c.
 * game_start() (dans game_logic.c) appelle game_timer_start(), qui
 * enregistre un adaptateur on_timer_tick(int) — sa "vraie"
 * implémentation vit dans src/main.c (avec rendu), une version
 * minimale est fournie ci-dessous pour les besoins du link.
 *
 * Ou plus simplement, depuis tests/ :  make test-integration
 */

#include "game_state.h"
#include "game_logic.h"
#include "ui_fonts.h"
#include "timer.h"
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <time.h>

/* Implémentation minimale requise par timer.c pour que l'édition de
   liens réussisse (voir game_timer_start dans src/timer.c). */
void on_timer_tick(int id) {
    (void)game_timer_callback(id);
}

int main(void) {
    srand((unsigned)time(NULL));
    layout_compute(); /* nécessaire : SW/SH utilisés indirectement */

    int total_runs = 200;
    for (int run = 0; run < total_runs; run++) {
        game_start(MODE_SOLO);

        int q = 0, z = 0;
        for (int r = 0; r < GRID_SIZE; r++) {
            for (int c = 0; c < GRID_SIZE; c++) {
                char ch = g.grid[r][c];
                assert(ch >= 'A' && ch <= 'Z');
                if (ch == 'Q') q++;
                if (ch == 'Z') z++;
            }
        }
        assert(q <= 1);
        assert(z <= 1);
    }

    printf("[OK] %d appels a game_start(MODE_SOLO) : grilles toutes "
           "valides (lettres A-Z, <=1 Q, <=1 Z) via dice_roll_grid.\n",
           total_runs);
    printf("\n=== TEST INTEGRATION GAME_START PASSE (1/1) ===\n");
    return 0;
}
