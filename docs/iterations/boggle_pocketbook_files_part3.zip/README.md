# Tests hôte — Boggle PocketBook

Ces tests permettent de vérifier la **logique** du jeu (règles,
navigation, score, timer, tirage des dés) sur votre machine de
développement (Linux/macOS/WSL), **sans** le SDK ARM PocketBook ni de
liseuse physique. Aucun rendu graphique n'est testé — uniquement le
comportement du code dans `src/`.

## Principe

Le code de `src/` n'appelle jamais directement de matériel : il passe
toujours par les fonctions déclarées dans `inkview.h` (`DrawString`,
`FillArea`, `SetHardTimer`...). `tests/stub/` fournit une réécriture
minimale de ce header avec des implémentations **no-op** (qui ne font
rien) de chaque fonction. En compilant les modules de `src/` contre ce
stub plutôt que contre le vrai SDK, on obtient un binaire qui tourne
nativement sur votre machine et permet d'exécuter — pas seulement de
lire — toute la logique métier.

```
tests/
├── stub/
│   ├── inkview.h          réécriture minimale du header InkView
│   └── inkview_stub.c     implémentations no-op de chaque fonction
├── test_flow.c            scénario de jeu complet (10 vérifications)
├── test_dice.c            tirage des 16 dés officiels (2 vérifications)
├── test_game_start_dice.c intégration game_start() <-> dice (1 vérification)
├── Makefile                compile + exécute tout en une commande
└── README.md               ce fichier
```

⚠️ **`tests/stub/inkview.h` ne doit jamais être utilisé pour le build
de production.** Le vrai build PocketBook (voir le `Makefile` et le
`CMakeLists.txt` à la racine du projet) utilise le `inkview.h` fourni
par le SDK officiel.

### Note sur `on_timer_tick`

`src/timer.c` est de la logique pure (aucun appel de dessin) ; il
enregistre auprès d'InkView un adaptateur `on_timer_tick(int)` dont la
"vraie" implémentation (avec rendu) vit dans `src/main.c`. Comme les
binaires de test ci-dessous ne compilent pas `main.c` (qui a son
propre `main()`), `test_flow.c` et `test_game_start_dice.c` fournissent
chacun une implémentation minimale de `on_timer_tick()` qui se
contente d'appeler `game_timer_callback()` sans rien dessiner —
suffisant pour satisfaire l'édition de liens et pour les scénarios
testés ici, qui appellent de toute façon `game_timer_callback()`
directement plutôt que de passer par le timer matériel simulé.

## Prérequis

Seulement `gcc` et `make` — aucun SDK PocketBook nécessaire.

## Exécution

Depuis ce dossier (`tests/`) :

```bash
make              # compile et exécute les 3 suites de tests
make test-flow         # uniquement le scénario de jeu complet
make test-dice         # uniquement le tirage des 16 dés officiels
make test-integration   # uniquement game_start() <-> dice
make clean        # supprime les binaires compilés (tests/bin/)
```

Une suite qui réussit affiche une série de lignes `[OK] ...` puis un
résumé `=== ... PASSE(S) (n/n) ===` et se termine avec le code de
sortie 0. Un échec arrête le programme sur le premier `assert()` qui
casse (signal `SIGABRT`) ; le dernier message `[OK]` affiché juste
avant indique quel scénario était en cours au moment de l'échec.

## Ce que vérifie chaque fichier

### `test_flow.c` — scénario de jeu complet

Rejoue un déroulé de partie de bout en bout via les vraies fonctions
publiques des modules (pas de copie ni de doublure) :

1. Initialisation (`fonts_load`, `layout_compute`)
2. Sélection du mode Solo via un tap simulé sur l'écran d'accueil
3. Sélection de deux cases adjacentes, dont une case Q → vérifie que
   le mot en construction contient bien le digraphe `QU`
4. Validation du mot → vérifie l'incrémentation du score et de la
   liste des mots trouvés
5. Revalidation du même mot → vérifie la détection de doublon
6. Décompte du timer jusqu'à 0:00 en mode solo → vérifie le
   `TimerTickResult` retourné (`TIMER_TICK_RUNNING` puis
   `TIMER_TICK_ENDED_SOLO`) et `g.game_over`
7. Décompte du timer jusqu'à 0:00 en mode multijoueur → vérifie le
   `TimerTickResult` (`TIMER_TICK_ENDED_MULTI`) et le passage à
   `SCREEN_MULTI_END` (la grille doit disparaître)
8. Tap sur la grille en mode multijoueur → vérifie qu'il est ignoré
9. Tap sur le bouton "Mode" du HUD → vérifie le retour à l'écran
   d'accueil
10. Touche Back depuis l'écran d'accueil → vérifie qu'aucun crash ne
    se produit

### `test_dice.c` — tirage des 16 dés officiels

Vérifie que `dice_roll_grid()` (dans `src/dice.c`) respecte les règles
physiques des 16 dés du Boggle 4×4 (source :
[baggle.org/regles.php](http://baggle.org/regles.php)) :

1. **Bijection exacte** : sur 500 tirages, chaque grille générée doit
   pouvoir s'expliquer par "chaque dé a montré une de ses 6 faces",
   les 16 dés étant tous utilisés une fois chacun. Vérifié par
   backtracking (voir l'avertissement dans le fichier sur le piège
   d'un algorithme glouton, qui donne de faux négatifs sur ce type de
   problème de couplage).
2. **Unicité du Q et du Z** : sur 2000 tirages, jamais plus d'un Q ni
   plus d'un Z dans la même grille — cohérent avec le fait qu'un seul
   dé porte chacune de ces lettres.

### `test_game_start_dice.c` — intégration

Vérifie que `game_start()`, le point d'entrée réellement appelé à
chaque nouvelle partie (depuis `input.c`), utilise bien
`dice_roll_grid()` en conditions normales — pas seulement que
`dice.c` fonctionne isolément. 200 parties sont lancées et chaque
grille produite est vérifiée (lettres A-Z valides, au plus un Q, au
plus un Z). Depuis le découplage timer/rendu, ce test n'a plus besoin
de lier les modules `screen_*` : `timer.c`, appelé indirectement via
`game_start()`, n'en dépend plus du tout.

## Étendre les tests

Pour ajouter un nouveau scénario, le plus simple est de l'ajouter
comme une étape supplémentaire dans `test_flow.c` (même pattern :
appeler une fonction publique d'un module, puis `assert()` sur l'état
attendu). Pour un nouveau fichier de test indépendant, l'ajouter au
`Makefile` en suivant le modèle des cibles existantes (`test-dice`,
`test-integration`) : lister les modules de `src/` réellement requis
par l'édition de liens, puis une règle qui compile et exécute.
