/* TEST-ONLY hooks, not part of the real InkView SDK. Kept separate
   from inkview.h so that file stays a faithful mirror of the real
   SDK header's shape. */

#ifndef STUB_HOOKS_H
#define STUB_HOOKS_H

/* Simulates a change of device language for tests. Affects what
   GetCurrentLangText() resolves to on subsequent calls. */
void stub_set_current_lang(const char *lang);

#endif /* STUB_HOOKS_H */
