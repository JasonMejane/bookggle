# i18n Plan — Tier 1: UI String Localization

## Goal

Every string the player sees (titles, buttons, dialogs) is looked up by
key and resolved against the device's current system language via the
InkView SDK, instead of being hardcoded English in the source.

## Real API this plan is built on

Confirmed present in `inkview.h` across PBSDK, FRSCSDK, and SDK_481
(so compatible with the SDK_6.3.0 already targeted by this project):

```c
void        AddTranslation(const char *label, const char *trans);
const char *GetLangText(const char *s);
const char *GetLangTextF(const char *s, ...);   // printf-style
char      **EnumLanguages(void);
void        LoadLanguage(const char *lang);
int         IsRTL(void);   // true if current system language is RTL
```

InkView tracks the device's active system language internally
(set in device Settings). `GetLangText()` resolves against it
automatically — the app never sniffs a locale itself. It resolves
labels the app registered via `AddTranslation()`; it is a lookup
table the app populates, not a magic dictionary.

`GetLangTextPlural` exists only in the newer SDK_481 (FW5) header —
not in PBSDK/FRSCSDK. Plan avoids depending on it (see Pluralization
below) so the app stays portable across SDK versions.

## Current inventory (baseline commit)

20 distinct hardcoded UI strings, found in:

| File | Strings |
|---|---|
| `screen_mode_select.c` | "BOGGLE", "Choose a game mode", "Solo", "Type your words on screen", "Multiplayer", "Shared grid — everyone notes their words" |
| `screen_game.c` | "BOGGLE Multi"/"BOGGLE Solo", "Score: %d", "Mode", "Submit", "Clear", "Words (%d)", "Note your words — grid disappears at 0:00" |
| `screen_multi_end.c` | "TIME'S UP!", "Compare your word lists.", "Words found by more than one player cancel out.", "New game", "Change mode" |
| `main.c` | "Time's up!\nFinal score: %d point%s", "Game over" |
| `game_logic.c` | "Too short"/"Word must be at least 3 letters.", "Already found"/"This word was already validated!", "Invalid word"/"This word is not in the dictionary." |

Non-translatable by design (kept as-is): "BOGGLE" (brand name),
`%02d:%02d` timer digits, `%d` selection-order digits, `%s +%d` score
line (structural, not prose).

## New module: `i18n`

Same one-concern-per-file pattern as `dice.c` / `timer.c`.

**`src/include/i18n.h`** — declares:
- `void i18n_init(void)` — called once from `EVT_INIT`, registers every
  key/text pair for every bundled language via `AddTranslation()`.
- String keys as an enum or `#define` list (e.g. `STR_BTN_SOLO`,
  `STR_MSG_TOO_SHORT`), one per row of the inventory table above.
- A thin lookup wrapper `const char *i18n_str(int key)` OR direct use
  of the SDK's `T(x)` macro at call sites — decide based on whether
  keys are enum-based (needs wrapper) or literal-identifier-based
  (macro works directly). Enum-based keys are preferred: they give
  compile-time errors on typos, where `T(x)` macro (`#x` stringified)
  silently produces a new, unmatched label string.

**`src/i18n.c`** — implements `i18n_init()`, includes the per-language
table headers below, calls `AddTranslation()` once per key per
language at startup.

## Per-language string tables (data, not code branches)

One file per locale, each a static array of `{key, text}` pairs:

```
src/i18n/strings_en.c
src/i18n/strings_fr.c
```

Adding a language = adding one new table file + one line in
`i18n_init()` to load it. No changes to any `screen_*.c` file.
`CMakeLists.txt` needs no edit (`file(GLOB src/*.c)` already picks up
new files); `Makefile`'s explicit source list needs the new files
added — one-line change per new file.

Table shape (illustrative, not final):
```c
static const LangEntry EN_STRINGS[] = {
    { STR_BTN_SOLO, "Solo" },
    { STR_MSG_TOO_SHORT, "Word must be at least 3 letters." },
    /* ... */
};
```

## Call-site changes

Mechanical replacement in the 5 files listed in the inventory table:
`"Solo"` → `i18n_str(STR_BTN_SOLO)`, etc. No file outside that list
needs to change — `game_state.h`, `timer.c`, `dice.c`, `input.c`,
`ui_fonts.c` hold no user-facing text today and stay untouched.

## Pluralization

`GetLangTextPlural` is SDK_481-only — not relied upon. Instead, the
one pluralized phrase (`"...Final score: %d point%s"` in `main.c`) is
split into two full keys selected by count, e.g.
`STR_SCORE_SINGULAR` / `STR_SCORE_PLURAL`, chosen in C before the
`Message()` call. This works on every SDK version and avoids
English-only `"%s"` grammar hacks that don't generalize to other
languages' plural rules (which may need more than 2 forms — this
2-form split is a known simplification, acceptable for the "point(s)"
case but flagged if more languages with 3+ plural forms are added
later).

## Layout safety — Tier 1.5, StringWidth() measurement

Several buttons currently have **fixed pixel widths** in `screen_game.c`
and `screen_mode_select.c` (e.g. the 100px "Submit"/"Clear" buttons).
Translated strings run longer in some languages (German especially).

Plan: at each button draw site, after resolving the string via
`i18n_str()`, call `StringWidth(text)` (already used elsewhere in the
codebase, e.g. `screen_game.c`'s grid-letter centering) and compare
against the button's fixed box width:

- If the measured width fits within the box (minus a small margin),
  draw as today, centered, with the current font.
- If it overflows, step down through the existing font ladder
  (`font_medium` → `font_small`) and re-measure, using the smallest
  font that fits.
- If it still overflows at the smallest font, this is treated as a
  content bug to fix in that language's string table (shorten the
  translation) rather than something the UI silently truncates or
  clips — truncating translated button text produces confusing,
  unreviewable UI in a language the maintainer may not read.

This measurement logic is small and repeated at every button draw
site, so it becomes a tiny shared helper (e.g.
`fit_text_in_box(text, box_w, box_h)` returning the font to use),
living in `i18n.c` or a small `ui_layout.c` helper — decided at
implementation time based on whether it's i18n-specific or general
layout logic.

## Fallback language

If `EnumLanguages()` reports a device language with no bundled table,
`i18n_init()` falls back to registering the English table as the
default `AddTranslation()` set, so `GetLangText()` never returns a
blank or raw key on an unsupported device language.

## Testing

`tests/stub/inkview.h` / `inkview_stub.c` need no-op stubs added for
`AddTranslation`, `GetLangText`, `EnumLanguages`, `LoadLanguage` so
`tests/test_flow.c` keeps compiling and running unmodified — the stub
`GetLangText` can simply echo back the key or the English table live
in-process, whichever keeps assertions in `test_flow.c` (which check
button hitboxes, not exact text) unaffected.

New host test: `tests/test_i18n.c` — walks every registered key
across every bundled language table and asserts none are missing
(catches an incomplete translation before it ships silently as a
blank string on-device). Add its target to `tests/Makefile` following
the existing `test-dice`/`test-integration` pattern.

## Scope boundary

This plan covers UI strings only. It does **not** touch the letter
dice table (`dice.c`) or the Q→"Qu" digraph rule (`game_logic.c`),
which are game-rules localization, not UI-string localization — see
the separate Tier 2 plan (`i18n_plan_tier2.md`).
