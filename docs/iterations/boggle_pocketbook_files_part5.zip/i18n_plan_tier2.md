# i18n Plan — Tier 2: Game Rules Localization

## Goal

Not just translated menus — an actually different Boggle *edition* per
language: correct letter distribution, correct digraph handling (or
none), and a language-appropriate minimum word length. This is a
separate, larger-scope effort from Tier 1 (UI strings) and should not
be bundled into it silently.

## Why this is a distinct tier

Tier 1 assumes the *rules* of the game are language-neutral and only
the *labels* around them need translating. That assumption breaks for
Boggle specifically:

- **Letter distribution is edition-specific.** The current 16-dice
  table in `dice.c` (`ETUKNO`, `EVGTIN`, ... `ENHRIS`) is the French
  B@ggle edition, sourced from baggle.org. The English Boggle edition
  uses a different, well-documented 16-dice set with different letter
  frequencies (e.g. more common English letters, no built-in Qu
  bias matching French vowel patterns). Using the French dice table
  with English words produces an unbalanced, non-authentic game.
- **The Q→"Qu" digraph is a French-rule artifact**, not a universal
  Boggle rule. `cell_label()` and `cell_contrib()` in `game_logic.c`
  hardcode this merge. Standard English Boggle typically keeps Q as
  a single tile (sometimes still shown as "Qu" on the physical die
  face, but not every edition/ruleset agrees) — this needs a
  per-edition flag, not a hardcoded `if (letter == 'Q')`.
- **Minimum word length varies by convention.** `MIN_WORD_LEN = 3` in
  `game_state.h` matches common English/French house rules, but some
  editions or house rules use different minimums.
- **Scoring table** (`score_for_word()` in `game_logic.c`) is
  currently the standard 1/1/2/3/5/11 table — this one does appear
  broadly stable across editions and is *not* expected to need
  per-language variation, but is called out here for completeness
  since it lives in the same function family as the above.

## Proposed architecture: a `GameRuleset` per language

Rather than scattering `if (lang == FR)` branches through
`game_logic.c` and `dice.c`, introduce a data-driven ruleset,
mirroring the Tier 1 pattern of "one file per language, not one
branch per feature":

```c
typedef struct {
    const char lang_code[8];         /* "fr", "en", ... */
    const char dice[DICE_COUNT][DICE_FACES];
    int        has_qu_digraph;       /* 1 = Q cell shows/contributes "QU" */
    int        min_word_len;
} GameRuleset;
```

**`src/rulesets/ruleset_fr.c`** — the current French table (moved
as-is from `dice.c`), `has_qu_digraph = 1`, `min_word_len = 3`.

**`src/rulesets/ruleset_en.c`** — the standard English 16-dice
distribution (needs sourcing — see Open Questions), `has_qu_digraph`
set per the chosen English house rule, `min_word_len` per convention
(commonly 3, to confirm against a citable English rules source before
implementation, not assumed).

`dice.c` and `game_logic.c` change from hardcoding the French table
and the Q rule to reading `active_ruleset->dice` and
`active_ruleset->has_qu_digraph`. `cell_label()` / `cell_contrib()`
branch on the flag instead of a hardcoded letter check.

## How the active ruleset is selected

Two independent axes, and they should **not** be conflated:

1. **UI language** (Tier 1) — what language buttons/messages are in.
2. **Game ruleset** (Tier 2) — which dice table and digraph rule are
   active.

A player's device might be in English while they still want to play
the French letter distribution (or vice versa) — these are genuinely
independent choices in how physical Boggle sets are marketed and
played regionally. Plan:

- Default: ruleset follows UI language 1:1 (device in French → French
  ruleset; device in English → English ruleset; unsupported UI
  language → falls back to whichever ruleset the Tier 1 fallback
  language uses).
- Optional (flag as a "nice to have", not required for a first pass):
  a settings toggle exposed on the mode-select screen letting the
  player pick the ruleset independently of UI language, since this is
  a real distinction Boggle players care about (`"French dice"` vs
  `"English dice"`), not just a translation nicety.

## Impact on existing modules

| File | Change |
|---|---|
| `dice.c` | Table becomes ruleset-provided, not a static `DICE[]` constant. `dice_roll_grid()` takes (or reads) the active ruleset. |
| `game_logic.c` | `cell_label()`/`cell_contrib()` branch on `ruleset->has_qu_digraph` instead of hardcoded `'Q'` check. `game_start()` reads `ruleset->min_word_len` instead of the `MIN_WORD_LEN` constant. |
| `game_state.h` | `MIN_WORD_LEN` constant either removed (fully ruleset-driven) or kept as a compiled-in default/fallback. |
| `screen_mode_select.c` | If the optional ruleset-picker UI is built, this screen gains a new control; otherwise unaffected. |

## Testing impact

`tests/test_dice.c` currently hardcodes an independent copy of the
French dice table to cross-check `dice_roll_grid()` against (see the
in-file note about the greedy-vs-backtracking bug found while writing
that test). Under Tier 2, this becomes parameterized: the same
bijection + Q/Z-uniqueness checks run once per bundled ruleset, each
against its own independently-transcribed reference table, not just
the French one. `tests/test_game_start_dice.c` similarly needs to
assert grid validity per active ruleset, not assume French rules
(e.g. the current `<=1 Q` assertion is French-digraph-specific and
would need to become conditional on `has_qu_digraph` for a hypothetical
English ruleset with a different Q-tile count).

## Open questions to resolve before implementation

1. **Sourcing the English (or other) dice table.** The French table
   was sourced and cited from baggle.org; an equivalent authoritative
   source needs to be found and cited for each additional edition
   before it's hardcoded — this should not be guessed or reconstructed
   from memory.
2. **Does English Boggle actually use "Qu" as a merged tile?** Needs
   confirming against a citable rules source (not assumed) — different
   commercial Boggle editions have disagreed on this over the years.
3. **Ruleset-picker UI or not?** Whether the independent ruleset
   toggle (vs. following UI language 1:1) is in scope for a first
   pass, or deferred.

## Scope boundary

This tier depends on Tier 1 existing first (the ruleset picker, if
built, needs translated labels too), but is otherwise independent
engineering effort — recommend treating it as a separate implementation
pass, only started once Tier 1 is shipped and the open questions above
are answered.
