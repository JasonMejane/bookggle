/* Mode select screen. */

#include "screen_mode_select.h"
#include "game_state.h"
#include "i18n.h"

void draw_mode_select(void) {
    FillArea(0, 0, SW, SH, WHITE);

    SetFont(font_title, BLACK);
    DrawTextRect(0, SH / 8, SW, 52, "BOGGLE", ALIGN_CENTER);

    SetFont(font_medium, BLACK);
    DrawTextRect(0, SH / 8 + 62, SW, 30,
                 i18n_str(STR_CHOOSE_MODE), ALIGN_CENTER);

    int bw = SW * 2 / 3, bh = 64, bx = (SW - bw) / 2;
    int solo_y  = SH * 2 / 5;
    int multi_y = solo_y + bh + 54;
    int btn_text_w = bw - 20;

    DrawRect(bx, solo_y, bw, bh, BLACK);
    const char *solo_label = i18n_str(STR_BTN_SOLO);
    SetFont(i18n_fit_font(solo_label, btn_text_w, font_large), BLACK);
    DrawTextRect(bx, solo_y + 10, bw, bh, solo_label, ALIGN_CENTER);
    SetFont(font_small, DGRAY);
    DrawTextRect(bx, solo_y + bh + 4, bw, 22,
                 i18n_str(STR_SOLO_HINT), ALIGN_CENTER);

    DrawRect(bx, multi_y, bw, bh, BLACK);
    const char *multi_label = i18n_str(STR_BTN_MULTIPLAYER);
    SetFont(i18n_fit_font(multi_label, btn_text_w, font_large), BLACK);
    DrawTextRect(bx, multi_y + 10, bw, bh, multi_label, ALIGN_CENTER);
    SetFont(font_small, DGRAY);
    DrawTextRect(bx, multi_y + bh + 4, bw, 22,
                 i18n_str(STR_MULTI_HINT), ALIGN_CENTER);

    FullUpdate();
}
