/* Official 16 Boggle dice + Fisher-Yates shuffle for grid roll. */

#include "dice.h"
#include "game_state.h"
#include <stdlib.h>

static const char DICE[DICE_COUNT][DICE_FACES] = {
    {'E','T','U','K','N','O'},
    {'E','V','G','T','I','N'},
    {'D','E','C','A','M','P'},
    {'I','E','L','R','U','W'},
    {'E','H','I','F','S','E'},
    {'R','E','C','A','L','S'},
    {'E','N','T','D','O','S'},
    {'O','F','X','R','I','A'},
    {'N','A','V','E','D','Z'},
    {'E','I','O','A','T','A'},
    {'G','L','E','N','Y','U'},
    {'B','M','A','Q','J','O'},
    {'T','L','I','B','R','A'},
    {'S','P','U','L','T','E'},
    {'A','I','M','S','O','R'},
    {'E','N','H','R','I','S'},
};

static void shuffle_indices(int *order, int n) {
    for (int i = n - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        int tmp = order[i];
        order[i] = order[j];
        order[j] = tmp;
    }
}

void dice_roll_grid(void) {
    int order[DICE_COUNT];
    for (int i = 0; i < DICE_COUNT; i++) order[i] = i;
    shuffle_indices(order, DICE_COUNT);

    for (int k = 0; k < DICE_COUNT; k++) {
        int r = k / GRID_SIZE;
        int c = k % GRID_SIZE;
        const char *die = DICE[order[k]];
        g.grid[r][c] = die[rand() % DICE_FACES];
    }
}
