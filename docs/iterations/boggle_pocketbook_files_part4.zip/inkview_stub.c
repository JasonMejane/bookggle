/* No-op bodies for inkview.h, just enough for the link to succeed
   and the game logic to run on a regular dev machine. */

#include "inkview.h"

int ScreenWidth(void)  { return 758; }
int ScreenHeight(void) { return 1024; }

ifont *OpenFont(const char *name, int size, int bold) {
    (void)name; (void)size; (void)bold;
    return (ifont *)1;
}

void CloseFont(ifont *font) { (void)font; }
void SetFont(ifont *font, int color) { (void)font; (void)color; }

void FillArea(int x, int y, int w, int h, int color) {
    (void)x; (void)y; (void)w; (void)h; (void)color;
}

void DrawRect(int x, int y, int w, int h, int color) {
    (void)x; (void)y; (void)w; (void)h; (void)color;
}

void DrawLine(int x1, int y1, int x2, int y2, int color) {
    (void)x1; (void)y1; (void)x2; (void)y2; (void)color;
}

void DrawString(int x, int y, const char *text) {
    (void)x; (void)y; (void)text;
}

void DrawTextRect(int x, int y, int w, int h, const char *text, int align) {
    (void)x; (void)y; (void)w; (void)h; (void)text; (void)align;
}

int StringWidth(const char *text) {
    (void)text;
    return 20;
}

void FullUpdate(void) {}
void PartialUpdate(int x, int y, int w, int h) {
    (void)x; (void)y; (void)w; (void)h;
}

void Message(int icon, const char *title, const char *text, int ms) {
    (void)icon; (void)title; (void)text; (void)ms;
}

void CloseApp(void) {}

/* No real event loop — tests call module functions directly. */
void InkViewMain(iv_handler handler) { (void)handler; }

int SetHardTimer(const char *name, iv_timer_handler handler, int ms) {
    (void)name; (void)handler; (void)ms;
    return 1;
}
