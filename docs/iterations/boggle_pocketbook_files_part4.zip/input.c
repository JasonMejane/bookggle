/* Touch and key event routing. */

#include "input.h"
#include "game_state.h"
#include "game_logic.h"
#include "screen_mode_select.h"
#include "screen_game.h"
#include "screen_multi_end.h"

static void handle_tap_mode_select(int tx, int ty) {
    int bw = SW * 2 / 3, bh = 64, bx = (SW - bw) / 2;
    int solo_y  = SH * 2 / 5;
    int multi_y = solo_y + bh + 54;

    if (tx >= bx && tx <= bx + bw) {
        if (ty >= solo_y && ty <= solo_y + bh) {
            game_start(MODE_SOLO);
            draw_game();
        } else if (ty >= multi_y && ty <= multi_y + bh) {
            game_start(MODE_MULTI);
            draw_game();
        }
    }
}

static void handle_tap_multi_end(int tx, int ty) {
    int bw = SW * 2 / 3, bh = 58, bx = (SW - bw) / 2;
    int replay_y = SH * 3 / 5;
    int sm_w = SW / 2, sm_h = 40, sm_x = (SW - sm_w) / 2;
    int sm_y = replay_y + bh + 18;

    if (tx >= bx && tx <= bx + bw &&
        ty >= replay_y && ty <= replay_y + bh) {
        game_start(MODE_MULTI);
        draw_game();
    } else if (tx >= sm_x && tx <= sm_x + sm_w &&
               ty >= sm_y && ty <= sm_y + sm_h) {
        cur_screen = SCREEN_MODE_SELECT;
        draw_mode_select();
    }
}

static void handle_tap_game(int tx, int ty) {
    if (tx >= mode_btn_x && tx <= mode_btn_x + mode_btn_w &&
        ty >= mode_btn_y && ty <= mode_btn_y + mode_btn_h) {
        cur_screen = SCREEN_MODE_SELECT;
        draw_mode_select();
        return;
    }

    if (g.mode == MODE_SOLO && !g.game_over) {
        int bar_y = GRID_Y + GRID_SIZE * CELL_SIZE + 14;
        int bx = SW - 110, by = bar_y + 6;

        if (tx >= bx && tx <= bx + 100 &&
            ty >= by && ty <= by + 36) {
            validate_word();
            draw_game();
            return;
        }
        if (tx >= bx && tx <= bx + 100 &&
            ty >= by + 44 && ty <= by + 76) {
            game_reset_selection();
            draw_game();
            return;
        }
    }

    handle_cell_touch(tx, ty);
    draw_game();
}

void input_handle_pointerup(int x, int y) {
    switch (cur_screen) {
    case SCREEN_MODE_SELECT: handle_tap_mode_select(x, y); break;
    case SCREEN_MULTI_END:   handle_tap_multi_end(x, y);   break;
    case SCREEN_GAME:        handle_tap_game(x, y);        break;
    }
}

void input_handle_keypress(int key) {
    if (key != KEY_BACK) return;

    if (cur_screen == SCREEN_GAME || cur_screen == SCREEN_MULTI_END) {
        cur_screen = SCREEN_MODE_SELECT;
        draw_mode_select();
    } else {
        CloseApp();
    }
}
