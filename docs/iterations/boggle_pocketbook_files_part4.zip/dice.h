/* Official 16-dice letter layout for 4x4 Boggle. Source:
   http://baggle.org/regles.php */

#ifndef DICE_H
#define DICE_H

#define DICE_COUNT 16
#define DICE_FACES 6

/* Shuffles the 16 dice into the grid, rolls one face per die.
   Fills g.grid. */
void dice_roll_grid(void);

#endif /* DICE_H */
