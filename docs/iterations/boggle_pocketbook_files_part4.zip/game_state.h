/* Shared types, constants, and global state. Included by all modules. */

#ifndef GAME_STATE_H
#define GAME_STATE_H

#include "inkview.h"
#include <stddef.h>

#define GRID_SIZE      4
#define MAX_WORD_LEN   34   /* 16 cells * 2 chars (QU) + '\0' */
#define MAX_WORDS      200
#define MIN_WORD_LEN   3
#define TIMER_SECONDS  180

typedef enum { MODE_SOLO = 0, MODE_MULTI = 1 } GameMode;

typedef enum {
    SCREEN_MODE_SELECT,
    SCREEN_GAME,
    SCREEN_MULTI_END
} Screen;

typedef struct {
    char     grid[GRID_SIZE][GRID_SIZE];
    int      selected[GRID_SIZE * GRID_SIZE];
    int      sel_count;
    char     current_word[MAX_WORD_LEN];
    char     found_words[MAX_WORDS][MAX_WORD_LEN];
    int      word_count;
    int      score;
    int      time_left;
    int      game_over;
    GameMode mode;
} GameState;

/* Defined once in game_state.c */
extern GameState g;
extern Screen    cur_screen;

extern ifont *font_title;
extern ifont *font_large;
extern ifont *font_medium;
extern ifont *font_small;

extern int SW, SH;
extern int CELL_SIZE, GRID_X, GRID_Y;

/* "Mode" button hitbox, set in screen_game.c, read in input.c */
extern int mode_btn_x, mode_btn_y, mode_btn_w, mode_btn_h;

#endif /* GAME_STATE_H */
