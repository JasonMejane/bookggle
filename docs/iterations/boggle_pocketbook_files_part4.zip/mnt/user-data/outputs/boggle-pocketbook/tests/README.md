# Host tests — Boggle PocketBook

Checks the game **logic** (rules, navigation, score, timer, dice roll)
on your dev machine (Linux/macOS/WSL) — no PocketBook SDK, no device.
No drawing is tested, only `src/` behavior.

## How

`src/` only touches hardware through `inkview.h` functions
(`DrawString`, `FillArea`, `SetHardTimer`...). `tests/stub/` is a
minimal no-op rewrite of that header, so the real modules link into a
binary that runs natively here.

```
tests/
├── stub/
│   ├── inkview.h          minimal InkView header rewrite
│   └── inkview_stub.c     no-op bodies
├── test_flow.c            full game scenario (10 checks)
├── test_dice.c            16 official dice roll (2 checks)
├── test_game_start_dice.c game_start() <-> dice integration (1 check)
├── Makefile
└── README.md
```

⚠️ **Never use `tests/stub/inkview.h` for the production build.** The
real PocketBook build (root `Makefile` / `CMakeLists.txt`) uses the
SDK's own `inkview.h`.

`src/timer.c` is pure logic; it registers `on_timer_tick(int)` with
InkView, whose real (drawing) body lives in `src/main.c`. Since these
test binaries don't compile `main.c` (it has its own `main()`),
`test_flow.c` and `test_game_start_dice.c` each provide a minimal
`on_timer_tick()` that just calls `game_timer_callback()` — enough to
link, since both call `game_timer_callback()` directly anyway.

## Requirements

`gcc` and `make` only.

## Run

From `tests/`:

```bash
make                    # build + run all 3 suites
make test-flow          # full game scenario only
make test-dice          # 16 official dice roll only
make test-integration   # game_start() <-> dice only
make clean              # remove compiled binaries (tests/bin/)
```

A passing suite prints `[OK] ...` lines then a `=== ... PASSED (n/n) ===`
summary, exit code 0. A failure aborts on the first broken `assert()`
(`SIGABRT`); the last `[OK]` line printed shows which step it was on.

## What each file checks

**`test_flow.c`** — full game scenario, calling real module functions
end to end: init, pick Solo via simulated tap, select two adjacent
cells (one is Q, checks the `QU` digraph), validate a word (score +
word list), revalidate it (duplicate rejected), timer to 0:00 in solo
(`TimerTickResult` + `g.game_over`), timer to 0:00 in multi
(`TIMER_TICK_ENDED_MULTI` + `SCREEN_MULTI_END`, grid must disappear),
touch ignored in multi mode, "Mode" button returns to mode select,
Back key from mode select doesn't crash.

**`test_dice.c`** — checks `dice_roll_grid()` against the 16 official
dice ([baggle.org/regles.php](http://baggle.org/regles.php)): exact
letter<->die bijection on 500 rolls (backtracking, not greedy — see
in-file note), and never more than one Q or Z on 2000 rolls.

**`test_game_start_dice.c`** — checks `game_start()` (the real
per-game entry point called from `input.c`) actually uses
`dice_roll_grid()`, not just that `dice.c` works in isolation. 200
games launched, every grid checked. Since timer.c has no `screen_*`
dependency, this test doesn't need to link them either.

## Adding tests

New scenario: add a step to `test_flow.c` (call a module function,
`assert()` the expected state). New standalone test file: add a target
to `Makefile` following `test-dice`/`test-integration` — list the
`src/` modules actually needed for the link, then a build+run rule.
