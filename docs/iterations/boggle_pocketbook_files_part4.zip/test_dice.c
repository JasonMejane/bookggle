/* Checks dice_roll_grid() against the 16 official dice:
   1. exact letter<->die bijection (each die used once)
   2. never more than one Q or one Z per grid (single dice for each)

   Note: bijection check uses backtracking, not greedy — greedy can
   consume a die that a later rare letter needed, giving false fails.

   Run: make test-dice (from tests/), or see tests/README.md. */

#include "game_state.h"
#include "dice.h"
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <time.h>

/* Independent copy of the dice table (must match src/dice.c), kept
   separate so this test checks dice_roll_grid() against a reference
   written elsewhere, not against its own internal table. */
static const char DICE[16][6] = {
    {'E','T','U','K','N','O'},
    {'E','V','G','T','I','N'},
    {'D','E','C','A','M','P'},
    {'I','E','L','R','U','W'},
    {'E','H','I','F','S','E'},
    {'R','E','C','A','L','S'},
    {'E','N','T','D','O','S'},
    {'O','F','X','R','I','A'},
    {'N','A','V','E','D','Z'},
    {'E','I','O','A','T','A'},
    {'G','L','E','N','Y','U'},
    {'B','M','A','Q','J','O'},
    {'T','L','I','B','R','A'},
    {'S','P','U','L','T','E'},
    {'A','I','M','S','O','R'},
    {'E','N','H','R','I','S'},
};

static int letter_on_die(int die_idx, char letter) {
    for (int f = 0; f < 6; f++)
        if (DICE[die_idx][f] == letter) return 1;
    return 0;
}

static int try_assign(const char *letters, int n, int idx, int *used) {
    if (idx == n) return 1;
    for (int d = 0; d < 16; d++) {
        if (!used[d] && letter_on_die(d, letters[idx])) {
            used[d] = 1;
            if (try_assign(letters, n, idx + 1, used)) return 1;
            used[d] = 0;
        }
    }
    return 0;
}

int main(void) {
    srand((unsigned)time(NULL));

    int total_runs = 500;
    for (int run = 0; run < total_runs; run++) {
        dice_roll_grid();

        char letters[16];
        int k = 0;
        for (int r = 0; r < GRID_SIZE; r++)
            for (int c = 0; c < GRID_SIZE; c++)
                letters[k++] = g.grid[r][c];

        int used[16] = {0};
        if (!try_assign(letters, 16, 0, used)) {
            fprintf(stderr,
                "[FAIL run %d] no valid letter<->die bijection found!\n", run);
            return 1;
        }
    }
    printf("[OK] %d rolls checked: each uses exactly the 16 official "
           "dice, one each, with a valid face.\n", total_runs);

    int max_q = 0, max_z = 0;
    int runs_qz = 2000;
    for (int run = 0; run < runs_qz; run++) {
        dice_roll_grid();
        int q = 0, z = 0;
        for (int r = 0; r < GRID_SIZE; r++)
            for (int c = 0; c < GRID_SIZE; c++) {
                if (g.grid[r][c] == 'Q') q++;
                if (g.grid[r][c] == 'Z') z++;
            }
        if (q > max_q) max_q = q;
        if (z > max_z) max_z = z;
        assert(q <= 1 && "more than one Q in the grid!");
        assert(z <= 1 && "more than one Z in the grid!");
    }
    printf("[OK] %d rolls: never more than one Q (max=%d) "
           "or one Z (max=%d) per grid.\n", runs_qz, max_q, max_z);

    printf("\n=== ALL DICE TESTS PASSED (2/2) ===\n");
    return 0;
}
