/* Single definition of all global state declared extern in game_state.h. */

#include "game_state.h"

GameState g;
Screen    cur_screen = SCREEN_MODE_SELECT;

ifont *font_title  = NULL;
ifont *font_large  = NULL;
ifont *font_medium = NULL;
ifont *font_small  = NULL;

int SW, SH;
int CELL_SIZE, GRID_X, GRID_Y;

int mode_btn_x, mode_btn_y, mode_btn_w, mode_btn_h;
