/* Multiplayer end screen. */

#include "screen_multi_end.h"
#include "game_state.h"

void draw_multi_end(void) {
    FillArea(0, 0, SW, SH, WHITE);

    SetFont(font_title, BLACK);
    DrawTextRect(0, SH / 8, SW, 52, "TIME'S UP!", ALIGN_CENTER);

    SetFont(font_medium, BLACK);
    DrawTextRect(0, SH / 8 + 70, SW, 32,
        "Compare your word lists.", ALIGN_CENTER);
    DrawTextRect(0, SH / 8 + 108, SW, 32,
        "Words found by more than one player cancel out.", ALIGN_CENTER);

    int bw = SW * 2 / 3, bh = 58, bx = (SW - bw) / 2;
    int replay_y = SH * 3 / 5;
    DrawRect(bx, replay_y, bw, bh, BLACK);
    SetFont(font_large, BLACK);
    DrawTextRect(bx, replay_y + 10, bw, bh, "New game", ALIGN_CENTER);

    int sm_w = SW / 2, sm_h = 40, sm_x = (SW - sm_w) / 2;
    int sm_y = replay_y + bh + 18;
    DrawRect(sm_x, sm_y, sm_w, sm_h, DGRAY);
    SetFont(font_medium, DGRAY);
    DrawTextRect(sm_x, sm_y + 8, sm_w, sm_h, "Change mode", ALIGN_CENTER);
}
