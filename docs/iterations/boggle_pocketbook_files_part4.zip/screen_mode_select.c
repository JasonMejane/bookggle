/* Mode select screen. */

#include "screen_mode_select.h"
#include "game_state.h"

void draw_mode_select(void) {
    FillArea(0, 0, SW, SH, WHITE);

    SetFont(font_title, BLACK);
    DrawTextRect(0, SH / 8, SW, 52, "BOGGLE", ALIGN_CENTER);

    SetFont(font_medium, BLACK);
    DrawTextRect(0, SH / 8 + 62, SW, 30,
                 "Choose a game mode", ALIGN_CENTER);

    int bw = SW * 2 / 3, bh = 64, bx = (SW - bw) / 2;
    int solo_y  = SH * 2 / 5;
    int multi_y = solo_y + bh + 54;

    DrawRect(bx, solo_y, bw, bh, BLACK);
    SetFont(font_large, BLACK);
    DrawTextRect(bx, solo_y + 10, bw, bh, "Solo", ALIGN_CENTER);
    SetFont(font_small, DGRAY);
    DrawTextRect(bx, solo_y + bh + 4, bw, 22,
                 "Type your words on screen", ALIGN_CENTER);

    DrawRect(bx, multi_y, bw, bh, BLACK);
    SetFont(font_large, BLACK);
    DrawTextRect(bx, multi_y + 10, bw, bh, "Multiplayer", ALIGN_CENTER);
    SetFont(font_small, DGRAY);
    DrawTextRect(bx, multi_y + bh + 4, bw, 22,
                 "Shared grid — everyone notes their words", ALIGN_CENTER);

    FullUpdate();
}
