/* Full game scenario, calls real module functions (no mocks).
   Run: make test-flow (from tests/), or see tests/README.md. */

#include "game_state.h"
#include "ui_fonts.h"
#include "game_logic.h"
#include "timer.h"
#include "screen_mode_select.h"
#include "screen_game.h"
#include "screen_multi_end.h"
#include "input.h"
#include <stdio.h>
#include <assert.h>
#include <string.h>

/* timer.c needs this symbol to link; real version (with drawing)
   lives in src/main.c, not built into this test binary. */
void on_timer_tick(int id) {
    (void)game_timer_callback(id);
}

int main(void) {
    /* init */
    fonts_load();
    layout_compute();
    cur_screen = SCREEN_MODE_SELECT;
    printf("[OK] init: SW=%d SH=%d CELL=%d\n", SW, SH, CELL_SIZE);

    /* pick solo mode via simulated tap */
    int bw = SW * 2 / 3, bh = 64, bx = (SW - bw) / 2;
    int solo_y = SH * 2 / 5;
    input_handle_pointerup(bx + bw / 2, solo_y + bh / 2);
    assert(cur_screen == SCREEN_GAME);
    assert(g.mode == MODE_SOLO);
    printf("[OK] solo mode picked -> SCREEN_GAME, mode=%d\n", g.mode);

    /* deterministic grid, Q forced at (0,0) for the QU digraph check */
    for (int r = 0; r < GRID_SIZE; r++)
        for (int c = 0; c < GRID_SIZE; c++)
            g.grid[r][c] = (char)('A' + r * GRID_SIZE + c);
    g.grid[0][0] = 'Q';

    int x0 = GRID_X + 0 * CELL_SIZE + CELL_SIZE / 2;
    int y0 = GRID_Y + 0 * CELL_SIZE + CELL_SIZE / 2;
    int x1 = GRID_X + 1 * CELL_SIZE + CELL_SIZE / 2;
    int y1 = GRID_Y + 0 * CELL_SIZE + CELL_SIZE / 2;

    handle_cell_touch(x0, y0);
    printf("[OK] touch cell0 (Q) -> current_word='%s'\n", g.current_word);
    assert(strcmp(g.current_word, "QU") == 0);

    handle_cell_touch(x1, y1);
    printf("[OK] touch cell1 (B) -> current_word='%s'\n", g.current_word);
    assert(strcmp(g.current_word, "QUB") == 0);

    /* word validation: score + word list */
    int word_count_before = g.word_count;
    int score_before = g.score;
    validate_word();
    assert(g.word_count == word_count_before + 1);
    assert(g.score == score_before + score_for_word(3));
    assert(g.sel_count == 0);
    printf("[OK] validate_word -> word_count=%d score=%d\n",
           g.word_count, g.score);

    /* duplicate word detection */
    handle_cell_touch(x0, y0);
    handle_cell_touch(x1, y1);
    int wc2 = g.word_count;
    validate_word();
    assert(g.word_count == wc2);
    printf("[OK] duplicate rejected, word_count unchanged (%d)\n", g.word_count);

    /* timer down to 0:00 in solo mode */
    g.time_left = 2;
    g.game_over = 0;
    TimerTickResult r1 = game_timer_callback(0);
    assert(r1 == TIMER_TICK_RUNNING);
    assert(g.time_left == 1 && !g.game_over);
    TimerTickResult r2 = game_timer_callback(0);
    assert(r2 == TIMER_TICK_ENDED_SOLO);
    assert(g.time_left == 0 && g.game_over);
    printf("[OK] solo timer -> TIMER_TICK_ENDED_SOLO, game_over=%d at 0:00\n",
           g.game_over);

    /* timer down to 0:00 in multi mode -> grid hidden */
    game_start(MODE_MULTI);
    assert(cur_screen == SCREEN_GAME);
    assert(g.mode == MODE_MULTI);
    g.time_left = 1;
    TimerTickResult r3 = game_timer_callback(0);
    assert(r3 == TIMER_TICK_ENDED_MULTI);
    assert(g.time_left == 0 && g.game_over);
    assert(cur_screen == SCREEN_MULTI_END);
    printf("[OK] multi timer -> TIMER_TICK_ENDED_MULTI, "
           "cur_screen=SCREEN_MULTI_END (grid hidden)\n");

    /* touch ignored in multi mode */
    game_start(MODE_MULTI);
    handle_cell_touch(x0, y0);
    assert(g.sel_count == 0);
    printf("[OK] touch ignored in multi mode (sel_count=%d)\n", g.sel_count);

    /* "Mode" HUD button returns to mode select */
    draw_game(); /* sets mode_btn_x/y/w/h for this tap */
    input_handle_pointerup(mode_btn_x + mode_btn_w / 2,
                            mode_btn_y + mode_btn_h / 2);
    assert(cur_screen == SCREEN_MODE_SELECT);
    printf("[OK] Mode button -> back to SCREEN_MODE_SELECT\n");

    /* Back key from mode select */
    input_handle_keypress(KEY_BACK);
    printf("[OK] KEY_BACK from mode_select handled without crash\n");

    fonts_free();
    printf("\n=== ALL FLOW TESTS PASSED (10/10) ===\n");
    return 0;
}
