/* Checks ruleset_select()/ruleset_active(): picks the right ruleset
   for a known device language, falls back to English for an unknown
   one, and never returns NULL (even before ruleset_select() is ever
   called).
   Run: make test-ruleset (from tests/), or see tests/README.md. */

#include "game_state.h"
#include "ruleset.h"
#include "i18n.h"
#include "stub_hooks.h"
#include <stdio.h>
#include <assert.h>
#include <string.h>

int main(void) {
    i18n_init();

    /* Never NULL, even before ruleset_select() has run -- defaults
       to English. */
    const GameRuleset *before = ruleset_active();
    assert(before != NULL);
    assert(strcmp(before->lang_code, "en") == 0);
    printf("[OK] ruleset_active() defaults to English before "
           "ruleset_select() is called\n");

    /* Device language "fr" -> French ruleset. */
    stub_set_current_lang("fr");
    ruleset_select();
    const GameRuleset *fr = ruleset_active();
    assert(strcmp(fr->lang_code, "fr") == 0);
    printf("[OK] device language 'fr' selects the French ruleset\n");

    /* Device language "en" -> English ruleset. */
    stub_set_current_lang("en");
    ruleset_select();
    const GameRuleset *en = ruleset_active();
    assert(strcmp(en->lang_code, "en") == 0);
    printf("[OK] device language 'en' selects the English ruleset\n");

    /* Unknown device language -> falls back to English, not a crash
       or a NULL ruleset. */
    stub_set_current_lang("zz");
    ruleset_select();
    const GameRuleset *fallback = ruleset_active();
    assert(fallback != NULL);
    assert(strcmp(fallback->lang_code, "en") == 0);
    printf("[OK] unknown device language falls back to the English ruleset\n");

    /* Sanity on the bundled data itself: both rulesets currently use
       the Qu digraph and a 3-letter minimum. */
    assert(fr->has_qu_digraph == 1);
    assert(en->has_qu_digraph == 1);
    assert(fr->min_word_len == 3);
    assert(en->min_word_len == 3);
    printf("[OK] both bundled rulesets use the Qu digraph and "
           "min_word_len=3\n");

    printf("\n=== RULESET TESTS PASSED ===\n");
    return 0;
}
