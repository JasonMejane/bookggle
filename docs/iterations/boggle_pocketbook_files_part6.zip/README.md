# Boggle for PocketBook — Developer Guide

Native C Boggle game for PocketBook e-readers, built on the InkView SDK.

## Game modes

- **Solo** — tap cells to spell words, live score, word list.
- **Multiplayer** — only the grid and timer are shown. Each player
  notes words on paper. At 0:00 the **grid disappears** and an end
  screen tells players to compare lists (words found by more than one
  player cancel out — standard Boggle rule).

Mode is picked at startup, or anytime via the **"Mode"** button
(top-right of the HUD), which returns to the mode-select screen.
The physical **Back** key does the same (or closes the app if already
on that screen).

## Language and rules follow the device's language

Every menu, button, and dialog is looked up by key (`src/i18n.c` /
`src/include/i18n.h`) and resolved against the device's current
system language automatically via the InkView SDK's
`GetCurrentLangText()` — no manual locale detection in the app. Two
languages ship today: English (`src/i18n_strings_en.c`) and French
(`src/i18n_strings_fr.c`). Adding another is one new table file plus
one line in `i18n_init()` — no changes to any `screen_*.c` file.

Buttons with fixed pixel widths (Submit/Clear/Mode/New game/Change
mode) use `i18n_fit_font()` to shrink through the font ladder
(`font_large` → `font_medium` → `font_small`) via `StringWidth()`
measurement, so a longer translation doesn't overflow its box.

The **grid roll and word rules also follow the device's language**,
via a `GameRuleset` (`src/include/ruleset.h`) — not just the menu
text. `ruleset_select()` picks the ruleset matching the device's
current language (same signal as the UI strings, piggybacked through
`i18n_str(STR_LANG_CODE)` — no separate detection mechanism) and
`ruleset_active()` returns it everywhere the game needs dice letters,
the Q/Qu digraph rule, or the minimum word length. Two rulesets ship
today, one dice table each:

```
English ("New Boggle" 16-dice set):
AAEEGN ABBJOO ACHOPS AFFKPS AOOTTW CIMOTU DEILRX DELRVY
DISTTY EEGHNW EEINSU EHRTVW EIOSST ELRTTY HIMNQU HLNNRZ

French (B@ggle, baggle.org/regles.php):
ETUKNO EVGTIN DECAMP IELRUW EHIFSE RECALS ENTDOS OFXRIA
NAVEDZ EIOATA GLENYU BMAQJO TLIBRA SPULTE AIMSOR ENHRIS
```

Each line is a 6-face die. `dice_roll_grid()` in **`src/dice.c`**
shuffles the active ruleset's 16 dice (Fisher-Yates) into the 16
cells, then rolls one face per die — unlike picking from a flat
letter-frequency bag, this guarantees at most one Q and one Z per
grid, since only one die carries each (true for both bundled dice
tables). Both rulesets also merge Q as **"Qu"**: the cell displays
`Qu`, selecting it inserts the `QU` digraph into the word being
built, and scoring counts **cells** walked (not characters) — so `QU`
is worth 1 cell like any other. This is a per-ruleset flag
(`has_qu_digraph`), not hardcoded, in case a future language's
convention differs.

Adding a third language's *rules* (not just its menu text) means a
new `ruleset_<code>.c` data file plus one line in `ruleset_select()`
— see `docs/i18n_plan_tier2.md` for the full design rationale,
including the citation trail for the English dice table (researched
from a [boardgames.stackexchange.com](https://boardgames.stackexchange.com/q/48151)
question and cross-checked against several independent published
transcriptions) and the open question the plan explicitly deferred
(a standalone ruleset picker independent of UI language — not built;
ruleset follows UI language 1:1).

---

## InkView SDK essentials

PocketBook apps are ARM ELF binaries linked against `libinkview.so`.
The SDK provides the cross-compiler and headers.

```c
int main(int argc, char **argv) {
    InkViewMain(main_handler);
    return 0;
}
```

`InkViewMain` runs the event loop; your code lives in
`main_handler(int type, int par1, int par2)`.

| Event             | Trigger              | par1 / par2         |
|--------------------|-----------------------|----------------------|
| `EVT_INIT`         | App startup           | —                    |
| `EVT_SHOW`         | Screen needs redraw    | —                    |
| `EVT_EXIT`         | App closing            | —                    |
| `EVT_KEYPRESS`     | Physical key pressed   | par1 = key code      |
| `EVT_POINTERUP`    | Finger lifted (touch)  | par1 = X, par2 = Y   |
| `EVT_POINTERDOWN`  | Finger pressed         | par1 = X, par2 = Y   |

```c
FillArea(x, y, w, h, WHITE);

ifont *f = OpenFont("LiberationSans", 24, 1);
SetFont(f, BLACK);
DrawString(x, y, "Hello!");
DrawTextRect(x, y, w, h, "centered text", ALIGN_CENTER);

DrawRect(x, y, w, h, BLACK);

FullUpdate();           // full refresh, slow, clean
PartialUpdate(x,y,w,h);  // fast, may ghost
```

> On e-ink, whatever is drawn stays until you cover it. Always
> `FillArea(..., WHITE)` before redrawing.

```c
SetHardTimer("MyTimer", my_callback, 1000);

static void my_callback(int id) {
    // ... update + PartialUpdate(...)
}
```

> Here, the countdown lives in **`src/timer.c`** and draws nothing —
> it returns a `TimerTickResult`. The adapter `on_timer_tick()` in
> **`src/main.c`** is the one actually registered with `SetHardTimer`
> (which requires `void(*)(int)`), and it picks the redraw.

---

## Project layout

One `.c` / `.h` pair per concern, headers in `src/include/`.

```
boggle-pocketbook/
├── src/
│   ├── include/
│   │   ├── game_state.h          shared types, constants, extern state
│   │   ├── ui_fonts.h            font loading + screen layout
│   │   ├── dice.h                16 official dice + roll
│   │   ├── game_logic.h          rules: grid, selection, score, Q/Qu
│   │   ├── timer.h               game timer
│   │   ├── i18n.h                string keys, translation lookup, fit-font
│   │   ├── ruleset.h             per-language dice/digraph/word-length rules
│   │   ├── screen_mode_select.h
│   │   ├── screen_game.h
│   │   ├── screen_multi_end.h
│   │   └── input.h               touch/key routing
│   ├── game_state.c       single definition of global state `g`
│   ├── ui_fonts.c
│   ├── dice.c              shuffle-and-roll mechanics only, no letters
│   ├── game_logic.c       pure logic, no drawing
│   ├── timer.c            pure logic, no drawing
│   ├── i18n.c             registration + lookup + fit-font
│   ├── i18n_strings_en.c  English string table
│   ├── i18n_strings_fr.c  French string table
│   ├── ruleset.c          selects active ruleset from device language
│   ├── ruleset_en.c       English dice table + rules
│   ├── ruleset_fr.c       French dice table + rules
│   ├── screen_mode_select.c
│   ├── screen_game.c
│   ├── screen_multi_end.c
│   ├── input.c
│   └── main.c              main_handler + main()
├── tests/             host tests, no SDK/device — see tests/README.md
├── docs/
│   ├── i18n_plan_tier1.md    UI string localization (implemented)
│   └── i18n_plan_tier2.md    game-rules localization (implemented)
├── CMakeLists.txt
├── Makefile
└── README.md
```

`game_state.h` is the shared-data contract, included almost
everywhere. `game_logic.c` and `timer.c` never call `Draw*`/`Fill*`
and never include a `screen_*.h` — pure logic, testable without
drawing (see `tests/`). `game_logic.c` calls `i18n_str()` (for its
warning dialogs) and `ruleset_active()` (for the Q/Qu digraph and
minimum word length), so it depends on `i18n.h` and `ruleset.h`, but
those are lookups, not drawing calls. `dice.c` depends on `ruleset.h`
too — it owns the shuffle/roll mechanics only, not any specific set
of letters.

`timer.c` can't register directly with `SetHardTimer` (its
`game_timer_callback` returns `TimerTickResult`, not `void`), so it
registers `on_timer_tick(int)` instead — declared in `timer.h`,
defined in `main.c`, which calls `game_timer_callback()` and chooses
the redraw. This keeps timer rules and screen rendering independently
changeable.

`ruleset.c` picks the active ruleset by reusing `i18n`'s own
device-language resolution rather than a second, separate detection
mechanism: each language table carries one extra, non-user-facing
entry (`STR_LANG_CODE`) whose translated value is simply its own
language code ("en", "fr"), and `ruleset_select()` reads that through
`i18n_str()` to know which `GameRuleset` to activate.

---

## PocketBook SDK

Get the SDK: https://github.com/pocketbook/SDK_6.3.0

Or use the Docker image:
```bash
docker pull 5keeve/pocketbook-sdk:6.3.0-b288-v1
```

## Build

```bash
export PBSDK=$HOME/SDK_6.3.0
make
```

CMake:
```bash
export PBSDK=$HOME/SDK_6.3.0
mkdir build && cd build
cmake .. -DCMAKE_TOOLCHAIN_FILE=$PBSDK/share/cmake/arm_conf.cmake
make
```

Docker, no local SDK install:
```bash
docker run --rm -v $(pwd):/project -w /project \
  5keeve/pocketbook-sdk:6.3.0-b288-v1 \
  sh -c 'arm-obreey-linux-gnueabi-gcc -Isrc/include src/*.c \
         -o boggle.app -linkview -lm'
```

Check the binary is ARM:
```bash
file boggle.app
# -> ELF 32-bit LSB executable, ARM, EABI5 ...
```

## Run logic without a device

`tests/` provides a no-op InkView stub so the game logic builds and
runs on a regular dev machine:

```bash
cd tests
make
```

Five suites: `test_flow.c` (full game scenario, 10 checks),
`test_dice.c` (16-dice roll, bijection + Q/Z uniqueness, once per
bundled ruleset), `test_game_start_dice.c` (game_start <-> dice
integration), `test_i18n.c` (translation completeness across
languages + fit-font sizing), `test_ruleset.c` (ruleset selection
from device language). See `tests/README.md` for details.

## Deploy to device

1. Connect over USB (mass storage mode)
2. Copy `boggle.app` to `/mnt/ext1/applications/boggle.app`
3. Disconnect, launch from the Applications menu

Or via SSH (dropbear):
```bash
scp boggle.app root@192.168.1.X:/mnt/ext1/applications/boggle.app
```

---

## Extending

**Dictionary** — `word_is_valid()` in `src/game_logic.c` only checks
length right now (against `ruleset_active()->min_word_len`). A real
dictionary needs one word list per language, not one global list —
natural fit alongside the existing per-language split: load
`dict_en.txt`/`dict_fr.txt` based on `ruleset_active()->lang_code`,
or add a `dict_path` field to `GameRuleset` itself. Sorted word list +
binary search:

```c
static char dict[50000][16];
static int  dict_size = 0;

void load_dict(void) {
    FILE *f = fopen("/mnt/ext1/applications/boggle.dict", "r");
    if (!f) return;
    while (fgets(dict[dict_size], 16, f) && dict_size < 50000) {
        dict[dict_size][strcspn(dict[dict_size], "\n")] = '\0';
        for (char *p = dict[dict_size]; *p; p++) *p = toupper(*p);
        dict_size++;
    }
    fclose(f);
}

int word_in_dict(const char *w) {
    int lo = 0, hi = dict_size - 1;
    while (lo <= hi) {
        int mid = (lo + hi) / 2;
        int cmp = strcmp(dict[mid], w);
        if (cmp == 0) return 1;
        if (cmp < 0) lo = mid + 1; else hi = mid - 1;
    }
    return 0;
}
```

**Screen refresh modes** — `FullUpdate()` is slow but clean,
`PartialUpdate(x,y,w,h)` is fast but may ghost. Use partial for
frequently-changing areas (grid, HUD), full for screen transitions.

---

## Links

- SDK & examples: https://github.com/pmartin/pocketbook-demo
- SDK Docker: https://github.com/Skeeve/SDK_6.3.0
- MobileRead forum: https://www.mobileread.com/forums/forumdisplay.php?f=225
- inkview.h headers: https://github.com/blchinezu/pocketbook-sdk
- French dice letter layout source: http://baggle.org/regles.php
- English dice letter layout source: https://boardgames.stackexchange.com/q/48151
