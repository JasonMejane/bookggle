/* French Boggle ruleset. Dice source: http://baggle.org/regles.php */

#include "ruleset.h"
#include "game_state.h" /* MIN_WORD_LEN */

const GameRuleset RULESET_FR = {
    .lang_code = "fr",
    .dice = {
        {'E','T','U','K','N','O'},
        {'E','V','G','T','I','N'},
        {'D','E','C','A','M','P'},
        {'I','E','L','R','U','W'},
        {'E','H','I','F','S','E'},
        {'R','E','C','A','L','S'},
        {'E','N','T','D','O','S'},
        {'O','F','X','R','I','A'},
        {'N','A','V','E','D','Z'},
        {'E','I','O','A','T','A'},
        {'G','L','E','N','Y','U'},
        {'B','M','A','Q','J','O'},
        {'T','L','I','B','R','A'},
        {'S','P','U','L','T','E'},
        {'A','I','M','S','O','R'},
        {'E','N','H','R','I','S'},
    },
    .has_qu_digraph = 1,
    .min_word_len = MIN_WORD_LEN,
};
