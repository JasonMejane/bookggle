/* Ruleset selection. See ruleset.h. */

#include "ruleset.h"
#include "i18n.h"
#include <string.h>

extern const GameRuleset RULESET_EN;
extern const GameRuleset RULESET_FR;

static const GameRuleset *g_active_ruleset = NULL;

void ruleset_select(void) {
    const char *lang = i18n_str(STR_LANG_CODE);
    if (strcmp(lang, "fr") == 0) {
        g_active_ruleset = &RULESET_FR;
    } else {
        g_active_ruleset = &RULESET_EN;
    }
}

const GameRuleset *ruleset_active(void) {
    return (g_active_ruleset != NULL) ? g_active_ruleset : &RULESET_EN;
}
