/* Per-language Boggle rules: dice letters, Q/Qu digraph, minimum
   word length. See docs/i18n_plan_tier2.md for the design rationale.

   The active ruleset is selected from the same device-language signal
   already used for UI strings (i18n's STR_LANG_CODE) -- one language,
   one consistent ruleset, no separate picker UI. */

#ifndef RULESET_H
#define RULESET_H

#include "dice.h" /* DICE_COUNT, DICE_FACES */

typedef struct {
    const char lang_code[8];
    const char dice[DICE_COUNT][DICE_FACES];
    int        has_qu_digraph;
    int        min_word_len;
} GameRuleset;

/* Picks the active ruleset from the current device language (via
   i18n_str(STR_LANG_CODE)) and caches it. Call once, from EVT_INIT,
   after i18n_init(). Falls back to the English ruleset if the
   resolved language code matches no bundled ruleset. */
void ruleset_select(void);

/* Currently active ruleset. Never NULL -- defaults to the English
   ruleset if ruleset_select() hasn't been called yet. */
const GameRuleset *ruleset_active(void);

#endif /* RULESET_H */
