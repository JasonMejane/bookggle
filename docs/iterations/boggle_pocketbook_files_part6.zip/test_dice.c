/* Checks dice_roll_grid() against each bundled ruleset's own 16
   dice, once per ruleset (English, French):
   1. exact letter<->die bijection (each die used once)
   2. never more than one Q or one Z per grid (single dice for each)

   Note: bijection check uses backtracking, not greedy -- greedy can
   consume a die that a later rare letter needed, giving false fails.

   Run: make test-dice (from tests/), or see tests/README.md. */

#include "game_state.h"
#include "dice.h"
#include "ruleset.h"
#include "i18n.h"
#include "stub_hooks.h"
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

typedef struct {
    const char *lang_code;
    const char  dice[16][6];
} RefTable;

/* Independent copies of each ruleset's dice table (must match
   src/ruleset_en.c / src/ruleset_fr.c), kept separate so this test
   checks dice_roll_grid() against a reference written elsewhere, not
   against its own internal table. */
static const RefTable REF_TABLES[] = {
    { "en", {
        {'A','A','E','E','G','N'},
        {'A','B','B','J','O','O'},
        {'A','C','H','O','P','S'},
        {'A','F','F','K','P','S'},
        {'A','O','O','T','T','W'},
        {'C','I','M','O','T','U'},
        {'D','E','I','L','R','X'},
        {'D','E','L','R','V','Y'},
        {'D','I','S','T','T','Y'},
        {'E','E','G','H','N','W'},
        {'E','E','I','N','S','U'},
        {'E','H','R','T','V','W'},
        {'E','I','O','S','S','T'},
        {'E','L','R','T','T','Y'},
        {'H','I','M','N','Q','U'},
        {'H','L','N','N','R','Z'},
    } },
    { "fr", {
        {'E','T','U','K','N','O'},
        {'E','V','G','T','I','N'},
        {'D','E','C','A','M','P'},
        {'I','E','L','R','U','W'},
        {'E','H','I','F','S','E'},
        {'R','E','C','A','L','S'},
        {'E','N','T','D','O','S'},
        {'O','F','X','R','I','A'},
        {'N','A','V','E','D','Z'},
        {'E','I','O','A','T','A'},
        {'G','L','E','N','Y','U'},
        {'B','M','A','Q','J','O'},
        {'T','L','I','B','R','A'},
        {'S','P','U','L','T','E'},
        {'A','I','M','S','O','R'},
        {'E','N','H','R','I','S'},
    } },
};
#define REF_TABLE_COUNT (int)(sizeof(REF_TABLES) / sizeof(REF_TABLES[0]))

static int letter_on_die(const RefTable *ref, int die_idx, char letter) {
    for (int f = 0; f < 6; f++)
        if (ref->dice[die_idx][f] == letter) return 1;
    return 0;
}

static int try_assign(const RefTable *ref, const char *letters, int n,
                       int idx, int *used) {
    if (idx == n) return 1;
    for (int d = 0; d < 16; d++) {
        if (!used[d] && letter_on_die(ref, d, letters[idx])) {
            used[d] = 1;
            if (try_assign(ref, letters, n, idx + 1, used)) return 1;
            used[d] = 0;
        }
    }
    return 0;
}

static void check_bijection(const RefTable *ref, int total_runs) {
    for (int run = 0; run < total_runs; run++) {
        dice_roll_grid();

        char letters[16];
        int k = 0;
        for (int r = 0; r < GRID_SIZE; r++)
            for (int c = 0; c < GRID_SIZE; c++)
                letters[k++] = g.grid[r][c];

        int used[16] = {0};
        if (!try_assign(ref, letters, 16, 0, used)) {
            fprintf(stderr,
                "[FAIL '%s' run %d] no valid letter<->die bijection found!\n",
                ref->lang_code, run);
            exit(1);
        }
    }
    printf("[OK] '%s': %d rolls checked, each uses exactly its 16 "
           "official dice, one each, with a valid face.\n",
           ref->lang_code, total_runs);
}

static void check_qz_uniqueness(const RefTable *ref, int total_runs) {
    int max_q = 0, max_z = 0;
    for (int run = 0; run < total_runs; run++) {
        dice_roll_grid();
        int q = 0, z = 0;
        for (int r = 0; r < GRID_SIZE; r++)
            for (int c = 0; c < GRID_SIZE; c++) {
                if (g.grid[r][c] == 'Q') q++;
                if (g.grid[r][c] == 'Z') z++;
            }
        if (q > max_q) max_q = q;
        if (z > max_z) max_z = z;
        assert(q <= 1 && "more than one Q in the grid!");
        assert(z <= 1 && "more than one Z in the grid!");
    }
    printf("[OK] '%s': %d rolls, never more than one Q (max=%d) "
           "or one Z (max=%d) per grid.\n",
           ref->lang_code, total_runs, max_q, max_z);
}

int main(void) {
    srand((unsigned)time(NULL));
    i18n_init();

    for (int i = 0; i < REF_TABLE_COUNT; i++) {
        const RefTable *ref = &REF_TABLES[i];
        stub_set_current_lang(ref->lang_code);
        ruleset_select();

        const GameRuleset *active = ruleset_active();
        assert(strcmp(active->lang_code, ref->lang_code) == 0);

        check_bijection(ref, 500);
        check_qz_uniqueness(ref, 2000);
    }

    printf("\n=== ALL DICE TESTS PASSED (%d rulesets x 2 checks) ===\n",
           REF_TABLE_COUNT);
    return 0;
}
